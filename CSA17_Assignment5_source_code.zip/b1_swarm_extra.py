"""b1_swarm_extra.py - A2.3 / A2.4 hand-trace support, A2.1 centralised-vs-swarm comparison, curves for figures."""
import numpy as np, pickle, b1_swarm as S

def grid_map(sw):
    rows = []
    for y in range(sw.h - 1, -1, -1):
        r = ''
        for x in range(sw.w):
            d = [i for i, p in enumerate(sw.pos) if p == (x, y)]
            r += (f'D{d[0]}' if d else (' .' if sw.unm[y, x] else ' #'))
            r += ' '
        rows.append('   ' + r)
    return '\n'.join(rows)

def trace(starts, steps, title, seed=1):
    free = np.ones((5, 5), bool)
    sw = S.Swarm(len(starts), free, seed, starts=starts, trace=True)
    for i in range(len(starts)): sw.head[i] = (1, 1)
    print('-' * 78); print(title); print('-' * 78)
    print('legend: Dk = drone k, "#" = marked (already observed, pheromone present), "." = unmarked')
    print(f't=0  covered={sw.covered_cnt}/25  positions={sw.pos}'); print(grid_map(sw))
    for _ in range(steps):
        sw.step(); t, row, cov = sw.log[-1]
        mv = '; '.join(f'D{i}->{p} [{k}, target={tg}, new={g}]' for i, p, tg, k, g in row)
        print(f't={t}  {mv}\n     covered={cov}/25  wasted-moves so far={sw.wasted}/{sw.total_moves}'); print(grid_map(sw))
        if cov == 25: print('     ** 100% covered **'); break
    return sw

if __name__ == '__main__':
    print('=' * 78); print('TASK A2.3 / A2.4  hand-trace support on a 5x5 grid, three drones, no controller'); print('=' * 78)
    trace([(0, 0), (4, 0), (2, 4)], 6, 'A2.3  spread start  D0=(0,0) D1=(4,0) D2=(2,4)')
    trace([(0, 0), (1, 0), (0, 1)], 6, 'A2.4  failure configuration: clustered start  D0=(0,0) D1=(1,0) D2=(0,1)')
    # --- A2.1 centralised vs swarm
    print('\n' + '=' * 90); print('A2.1 diagnosis: centralised controller vs decentralised swarm (40x40, N=10 and 25, 30 seeds)'); print('=' * 90)
    print(f"{'N':>3} {'design':<11}{'scenario':<34}{'success':>8}{'final cov %':>13}{'msgs/step':>10}{'max load on 1 node':>20}")
    out = {}
    for n in (10, 25):
        for mode in ('central', 'swarm'):
            for name, ff, cf in (('no failure', 0, None), ('controller/link down at t=30', 0, 30),
                                 ('30% drones fail', .3, None), ('30% drones + controller down t=30', .3, 30)):
                rs = [S.Swarm(n, S.make_world(sd), sd, ff, mode=mode, ctrl_fail_at=cf).run() for sd in range(30)]
                sr = np.mean([r['success'] for r in rs]); fc = np.mean([r['final_cov'] for r in rs]) * 100
                ms = np.mean([r['msgs_per_step'] for r in rs]); mx = np.mean([r['max_node_msgs'] for r in rs])
                out[(n, mode, name)] = (sr, fc, ms, mx)
                print(f'{n:>3} {mode:<11}{name:<34}{sr:>8.0%}{fc:>13.1f}{ms:>10.1f}{mx:>20.1f}')
    pickle.dump(out, open('out/central_vs_swarm.pkl', 'wb'))
    # --- curves for figures
    R = S.experiment(); curves = {k: np.mean([r['curve'] for r in v], axis=0) for k, v in R.items()}
    summ = {k: dict(success=np.mean([r['success'] for r in v]), cov=np.mean([r['final_cov'] for r in v]),
                    red=np.mean([r['redundancy'] for r in v]), pb=np.mean([r['per_drone_batt'] for r in v]),
                    lat=np.mean([r['lat_us'] for r in v]), t90=np.nanmean([r['t90'] if r['t90'] is not None else np.nan for r in v]),
                    moves=np.mean([r['moves'] for r in v])) for k, v in R.items()}
    pickle.dump((curves, summ), open('out/swarm_curves.pkl', 'wb'))
