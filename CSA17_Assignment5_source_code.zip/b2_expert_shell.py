"""
b2_expert_shell.py - Tasks A3 / B2.  Generic forward-chaining expert-system shell + pump-fault knowledge base.
Engine (Shell) is domain-free: it only knows Rule(id, conditions, conclusion, kind, priority, cf).
Rules live in a text DSL that can be edited at run time (knowledge-acquisition interface).
DSL:  RULE r07 | IF a AND b AND NOT c | THEN derive x            (intermediate fact, always fires)
      RULE r12 | IF a AND x          | THEN fault cavitation | PRIORITY 3 | CF 0.8
Cases are 30 hand-written, synthetic expert-style labelled cases (no real plant data available offline).
"""
import copy, itertools
from collections import defaultdict, Counter

class Rule:
    def __init__(s, rid, pos, neg, concl, kind, prio=1, cf=1.0):
        s.id, s.pos, s.neg, s.concl, s.kind, s.prio, s.cf = rid, list(pos), list(neg), concl, kind, prio, cf
    def text(s):
        conds = ' AND '.join(s.pos + ['NOT ' + n for n in s.neg])
        return f"{s.id}: IF {conds} THEN {s.kind} {s.concl}" + (f" [priority {s.prio}, CF {s.cf}]" if s.kind == 'fault' else '')

def parse_rule(line):
    parts = [p.strip() for p in line.split('|')]
    rid = parts[0].split()[1]; conds = parts[1][3:].split(' AND ')
    pos = [c.strip() for c in conds if not c.strip().startswith('NOT ')]; neg = [c.strip()[4:] for c in conds if c.strip().startswith('NOT ')]
    th = parts[2][5:].split(); kind, concl = th[0], th[1]; prio, cf = 1, 1.0
    for p in parts[3:]:
        if p.startswith('PRIORITY'): prio = int(p.split()[1])
        if p.startswith('CF'): cf = float(p.split()[1])
    return Rule(rid, pos, neg, concl, kind, prio, cf)

class Shell:
    STRATS = ('specificity', 'priority', 'recency', 'order')
    def __init__(s, rules_text=None, strategy='specificity'):
        s.rules = []; s.strategy = strategy
        for ln in (rules_text or []): s.add_rule(ln)
    # ---- knowledge-acquisition interface
    def add_rule(s, line):
        r = parse_rule(line); s.rules = [x for x in s.rules if x.id != r.id] + [r]
    def remove_rule(s, rid): s.rules = [x for x in s.rules if x.id != rid]
    # ---- inference
    def diagnose(s, evidence, strategy=None):
        strat = strategy or s.strategy
        wm = {f: 0 for f in evidence}            # fact -> recency stamp
        why_src = {f: ('given', None) for f in evidence}
        fired = []; tick = 1; unknown = []
        while True:
            cs = [r for r in s.rules if r.id not in fired and all(p in wm for p in r.pos) and not any(n in wm for n in r.neg)]
            if not cs: break
            derive = [r for r in cs if r.kind == 'derive']
            if derive:                           # derived facts are monotonic: fire all, order irrelevant
                for r in derive:
                    fired.append(r.id)
                    if r.concl not in wm: wm[r.concl] = tick; why_src[r.concl] = ('rule', r)
                tick += 1; continue
            faults = cs
            key = {'specificity': lambda r: (len(r.pos) + len(r.neg), r.prio),
                   'priority': lambda r: (r.prio, len(r.pos)),
                   'recency': lambda r: (max(wm[p] for p in r.pos), len(r.pos)),
                   'order': lambda r: (-s.rules.index(r),)}[strat]
            winner = max(faults, key=key); fired.append(winner.id)
            return dict(fault=winner.concl, rule=winner, matched=[r.id for r in faults], fired=fired, wm=wm, why=why_src,
                        cf=winner.cf, strategy=strat, alt=sorted({r.concl for r in faults}))
        # nothing fired: report what evidence would unlock the closest rule (WHY-question support)
        live = [r for r in s.rules if r.kind == 'fault' and not any(n in wm for n in r.neg)]       # rules not vetoed by a NOT
        near = sorted(live, key=lambda r: (len([p for p in r.pos if p not in wm]), -len([p for p in r.pos if p in wm])))
        need = [p for p in near[0].pos if p not in wm] if near else []
        return dict(fault='undetermined', rule=None, matched=[], fired=fired, wm=wm, why=why_src, cf=0, strategy=strat,
                    alt=[], need=need, ask_rule=near[0] if near else None)
    # ---- explanation facility
    def how(s, res):
        if res['rule'] is None: return 'HOW: no fault rule could fire with the supplied evidence.'
        lines = [f"HOW: diagnosis '{res['fault']}' because rule {res['rule'].id} fired (CF {res['cf']}, strategy={res['strategy']})."]
        def expand(f, depth=1):
            kind, r = res['why'][f]
            if kind == 'given': lines.append('  ' * depth + f'- {f}  [observed]')
            else:
                lines.append('  ' * depth + f'- {f}  [derived by {r.id}: IF {" AND ".join(r.pos)}]')
                for p in r.pos: expand(p, depth + 1)
        for p in res['rule'].pos: expand(p)
        if len(res['alt']) > 1: lines.append(f"  (other faults also matched: {', '.join(a for a in res['alt'] if a != res['fault'])}; chosen by {res['strategy']})")
        return '\n'.join(lines)
    def why(s, res):
        if res['rule'] is not None: return 'WHY: no further evidence needed - a fault rule is satisfied.'
        r = res['ask_rule']
        return (f"WHY do I need more evidence? Closest rule {r.id} ({r.concl}) is missing: {', '.join(res['need'])}. "
                f"Please check: {', '.join(res['need'])}.")

PUMP_RULES = [
 # intermediate (derived) facts
 "RULE r01 | IF vibration_high AND grinding_noise | THEN derive mechanical_noise_vib",
 "RULE r02 | IF crackling_noise AND pressure_fluctuating | THEN derive hydraulic_instability",
 "RULE r03 | IF flow_low AND discharge_pressure_low | THEN derive hydraulic_performance_drop",
 "RULE r04 | IF current_high AND motor_hot | THEN derive electrical_stress",
 "RULE r05 | IF bearing_temp_high AND vibration_high | THEN derive bearing_heat_vib",
 # cavitation
 "RULE r06 | IF hydraulic_instability AND suction_pressure_low | THEN fault cavitation | PRIORITY 2 | CF 0.9",
 "RULE r07 | IF crackling_noise AND suction_pressure_low | THEN fault cavitation | PRIORITY 2 | CF 0.7",
 "RULE r08 | IF hydraulic_performance_drop AND vibration_high AND crackling_noise | THEN fault cavitation | PRIORITY 2 | CF 0.75",
 # seal failure
 "RULE r09 | IF shaft_leak AND pressure_fluctuating | THEN fault seal_failure | PRIORITY 3 | CF 0.8",
 "RULE r10 | IF shaft_leak AND NOT vibration_high | THEN fault seal_failure | PRIORITY 3 | CF 0.85",
 "RULE r11 | IF shaft_leak AND fluid_hot | THEN fault seal_failure | PRIORITY 3 | CF 0.7",
 # bearing failure
 "RULE r12 | IF bearing_heat_vib AND grinding_noise | THEN fault bearing_failure | PRIORITY 4 | CF 0.95",
 "RULE r13 | IF bearing_temp_high AND grinding_noise | THEN fault bearing_failure | PRIORITY 4 | CF 0.85",
 "RULE r14 | IF mechanical_noise_vib AND bearing_temp_high | THEN fault bearing_failure | PRIORITY 4 | CF 0.9",
 # impeller blockage
 "RULE r15 | IF flow_zero AND current_high | THEN fault impeller_blockage | PRIORITY 3 | CF 0.8",
 "RULE r16 | IF hydraulic_performance_drop AND current_high AND NOT crackling_noise | THEN fault impeller_blockage | PRIORITY 3 | CF 0.75",
 "RULE r17 | IF flow_low AND current_high AND vibration_high AND NOT suction_pressure_low | THEN fault impeller_blockage | PRIORITY 3 | CF 0.7",
 # motor overload
 "RULE r18 | IF electrical_stress AND tripping | THEN fault motor_overload | PRIORITY 4 | CF 0.9",
 "RULE r19 | IF electrical_stress AND NOT flow_zero AND NOT flow_low | THEN fault motor_overload | PRIORITY 4 | CF 0.8",
 "RULE r20 | IF tripping AND current_high | THEN fault motor_overload | PRIORITY 4 | CF 0.75",
]
FAULTS = ['cavitation', 'seal_failure', 'bearing_failure', 'impeller_blockage', 'motor_overload']

def S(s): return set(s.split())
# 30 expert-style labelled cases: (id, evidence, true fault).  cases 1-15 = development set, 16-30 = hold-out
CASES = [
 ('c01', S('crackling_noise pressure_fluctuating suction_pressure_low vibration_high'), 'cavitation'),
 ('c02', S('crackling_noise suction_pressure_low flow_low'), 'cavitation'),
 ('c03', S('shaft_leak pressure_fluctuating'), 'seal_failure'),
 ('c04', S('shaft_leak fluid_hot flow_low'), 'seal_failure'),
 ('c05', S('bearing_temp_high grinding_noise vibration_high'), 'bearing_failure'),
 ('c06', S('bearing_temp_high grinding_noise'), 'bearing_failure'),
 ('c07', S('flow_zero current_high discharge_pressure_low'), 'impeller_blockage'),
 ('c08', S('flow_low discharge_pressure_low current_high'), 'impeller_blockage'),
 ('c09', S('current_high motor_hot tripping'), 'motor_overload'),
 ('c10', S('current_high motor_hot'), 'motor_overload'),
 ('c11', S('crackling_noise suction_pressure_low vibration_high flow_low discharge_pressure_low'), 'cavitation'),
 ('c12', S('shaft_leak vibration_high pressure_fluctuating'), 'seal_failure'),
 ('c13', S('vibration_high grinding_noise bearing_temp_high motor_hot'), 'bearing_failure'),
 ('c14', S('flow_zero current_high vibration_high'), 'impeller_blockage'),
 ('c15', S('tripping current_high flow_low'), 'motor_overload'),
 # ---- hold-out
 ('c16', S('crackling_noise pressure_fluctuating suction_pressure_low'), 'cavitation'),
 ('c17', S('crackling_noise discharge_pressure_low flow_low vibration_high'), 'cavitation'),
 ('c18', S('shaft_leak pressure_fluctuating fluid_hot'), 'seal_failure'),
 ('c19', S('shaft_leak flow_low'), 'seal_failure'),
 ('c20', S('bearing_temp_high vibration_high grinding_noise discharge_pressure_low'), 'bearing_failure'),
 ('c21', S('grinding_noise vibration_high bearing_temp_high'), 'bearing_failure'),
 ('c22', S('flow_zero current_high motor_hot'), 'impeller_blockage'),
 ('c23', S('flow_low discharge_pressure_low current_high vibration_high'), 'impeller_blockage'),
 ('c24', S('current_high motor_hot flow_low'), 'motor_overload'),
 ('c25', S('tripping current_high motor_hot'), 'motor_overload'),
 ('c26', S('crackling_noise suction_pressure_low shaft_leak'), 'cavitation'),            # noisy: stray leak symptom
 ('c27', S('vibration_high flow_low'), 'impeller_blockage'),                             # sparse evidence
 ('c28', S('shaft_leak vibration_high bearing_temp_high grinding_noise'), 'bearing_failure'),  # leak + bearing: conflict
 ('c29', S('current_high flow_low discharge_pressure_low crackling_noise'), 'impeller_blockage'),  # looks hydraulic
 ('c30', S('motor_hot current_high tripping flow_low'), 'motor_overload'),
]

def evaluate(shell, cases, strategy=None, verbose=False):
    rows = []
    for cid, ev, truth in cases:
        r = shell.diagnose(ev, strategy); rows.append((cid, truth, r['fault'], len(r['fired']), r))
    acc = sum(t == p for _, t, p, _, _ in rows) / len(rows)
    per = {}
    for f in FAULTS:
        tp = sum(1 for _, t, p, _, _ in rows if t == f and p == f); fp = sum(1 for _, t, p, _, _ in rows if t != f and p == f)
        fn = sum(1 for _, t, p, _, _ in rows if t == f and p != f)
        per[f] = (tp / (tp + fp) if tp + fp else float('nan'), tp / (tp + fn) if tp + fn else float('nan'), tp + fn)
    return acc, per, rows

if __name__ == '__main__':
    sh = Shell(PUMP_RULES)
    print('=' * 96); print(f'TASK B2.1  pump-fault shell: {len(sh.rules)} rules ({sum(r.kind=="fault" for r in sh.rules)} fault rules, {sum(r.kind=="derive" for r in sh.rules)} derived-fact rules), 5 faults'); print('=' * 96)
    for r in sh.rules: print('  ' + r.text())
    dev, hold = CASES[:15], CASES[15:]
    for name, cs in (('DEVELOPMENT (15 cases used to write/tune rules)', dev), ('HOLD-OUT (15 unseen cases)', hold)):
        acc, per, rows = evaluate(sh, cs)
        print(f'\n--- {name}: accuracy = {acc:.3f} ({sum(t==p for _,t,p,_,_ in rows)}/{len(rows)}), strategy = specificity')
        print(f"{'fault':<18}{'precision':>10}{'recall':>8}{'support':>8}")
        for f, (p, r, n) in per.items(): print(f'{f:<18}{p:>10.2f}{r:>8.2f}{n:>8}')
        print('mean rules fired per case = %.1f' % (sum(x[3] for x in rows) / len(rows)))
        print(f"{'case':<5}{'truth':<19}{'predicted':<19}{'fired':>5}  ok")
        for cid, t, p, nf, _ in rows: print(f'{cid:<5}{t:<19}{p:<19}{nf:>5}  {"Y" if t==p else "N  <--"}')
    print('\n--- sample explanations (hold-out) ---')
    for cid in ('c20', 'c23', 'c27'):
        ev = next(e for c, e, _ in CASES if c == cid); r = sh.diagnose(ev)
        print(f'[{cid}] evidence = {sorted(ev)}'); print(f"  diagnosis = {r['fault']}"); print('  ' + sh.how(r).replace('\n', '\n  ')); print('  ' + sh.why(r)); print()
