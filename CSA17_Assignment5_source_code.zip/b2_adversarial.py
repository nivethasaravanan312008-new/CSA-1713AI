"""b2_adversarial.py - B2.2 adversarial cases (predictions written BEFORE running) and B2.3 knowledge-acquisition regression."""
from b2_expert_shell import *

ADV = [  # (name, evidence, what it attacks, {strategy: PREDICTED outcome}, written before running)
 ('AC1 conflict: cavitation vs bearing', S('crackling_noise suction_pressure_low grinding_noise bearing_temp_high'), 'conflicting rules r07 (cav, prio2) vs r13 (bearing, prio4), same specificity',
  dict(specificity='bearing_failure', priority='bearing_failure', recency='cavitation', order='cavitation')),
 ('AC2 conflict: seal vs bearing', S('shaft_leak fluid_hot bearing_temp_high grinding_noise'), 'conflicting rules r11 (seal, prio3) vs r13 (bearing, prio4)',
  dict(specificity='bearing_failure', priority='bearing_failure', recency='seal_failure', order='seal_failure')),
 ('AC3 missing evidence: one symptom', S('flow_low'), 'insufficient evidence -> engine must not guess',
  dict(specificity='undetermined', priority='undetermined', recency='undetermined', order='undetermined')),
 ('AC4 missing evidence: current only', S('current_high'), 'insufficient evidence for motor_overload (needs tripping/motor_hot)',
  dict(specificity='undetermined', priority='undetermined', recency='undetermined', order='undetermined')),
 ('AC5 specificity trap: 3-cond rule vs high priority', S('crackling_noise discharge_pressure_low flow_low vibration_high current_high suction_pressure_low'), 'r08 (cav, 3 conds, prio2) vs r17 blocked by NOT; r16 blocked by NOT crackling',
  dict(specificity='cavitation', priority='cavitation', recency='cavitation', order='cavitation')),
]

def reversed_kb():
    sh = Shell(PUMP_RULES); sh.rules = list(reversed(sh.rules)); return sh

if __name__ == '__main__':
    sh = Shell(PUMP_RULES)
    print('=' * 110); print('TASK B2.2  adversarial cases: PREDICTION (written first) vs ACTUAL, four conflict-resolution strategies'); print('=' * 110)
    hits = tot = 0
    for name, ev, why, pred in ADV:
        print(f'\n{name}\n  evidence: {sorted(ev)}\n  attack  : {why}')
        print(f"  {'strategy':<12}{'predicted':<20}{'actual':<20}{'match':<6}{'matched rules':<22}{'fired'}")
        for st in Shell.STRATS:
            r = sh.diagnose(ev, st); ok = r['fault'] == pred[st]; hits += ok; tot += 1
            print(f"  {st:<12}{pred[st]:<20}{r['fault']:<20}{'Y' if ok else 'N':<6}{','.join(r['matched']):<22}{len(r['fired'])}")
    print(f'\nprediction accuracy: {hits}/{tot}')
    print('\n--- rule-order dependence: same evidence, KB listed in REVERSE order ---')
    rv = reversed_kb(); print(f"  {'case':<38}{'strategy':<13}{'original order':<19}{'reversed order':<19}changed?")
    for name, ev, _, _ in ADV[:2]:
        for st in Shell.STRATS:
            a, b = sh.diagnose(ev, st)['fault'], rv.diagnose(ev, st)['fault']
            print(f"  {name:<38}{st:<13}{a:<19}{b:<19}{'YES <-- order-dependent' if a != b else 'no'}")
    print('\n--- strategy comparison on labelled data (accuracy) ---')
    print(f"  {'strategy':<13}{'dev (15)':>9}{'hold-out (15)':>14}{'all 30':>8}{'ambiguous cases resolved correctly*':>38}")
    amb = [c for c in CASES if len(sh.diagnose(c[1], 'specificity')['matched']) > 1]
    for st in Shell.STRATS:
        d = evaluate(sh, CASES[:15], st)[0]; h = evaluate(sh, CASES[15:], st)[0]; a = evaluate(sh, CASES, st)[0]
        okamb = sum(sh.diagnose(e, st)['fault'] == t for _, e, t in amb)
        print(f"  {st:<13}{d:>9.3f}{h:>14.3f}{a:>8.3f}{f'{okamb}/{len(amb)}':>38}")
    print('  *cases where more than one fault rule was applicable (|conflict set| > 1): ', [c[0] for c in amb])
    # ------------------------------------------------------------ B2.3
    print('\n' + '=' * 110); print('TASK B2.3  knowledge acquisition at run time (no engine code changed) + regression run'); print('=' * 110)
    def snapshot(shell, st): return {c: shell.diagnose(e, st)['fault'] for c, e, _ in CASES}
    def run_ka(edits, st):
        s2 = Shell(PUMP_RULES, st); before = snapshot(s2, st); acc0 = evaluate(s2, CASES, st)[0]
        for e in edits: s2.add_rule(e) if e.startswith('RULE') else s2.remove_rule(e.split()[1])
        after = snapshot(s2, st); acc1 = evaluate(s2, CASES, st)[0]
        truth = {c: t for c, _, t in CASES}
        ch = [(c, before[c], after[c]) for c in before if before[c] != after[c]]
        print(f"  strategy={st}: accuracy {acc0:.3f} -> {acc1:.3f}; diagnoses changed: {len(ch)}")
        for c, b, a in ch: print(f"     {c}: {b:<18} -> {a:<18} (truth {truth[c]:<18}) {'FIXED' if a == truth[c] else ('REGRESSION' if b == truth[c] else 'still wrong')}")
    E1 = ["RULE r21 | IF current_high AND motor_hot AND flow_low | THEN fault motor_overload | PRIORITY 4 | CF 0.7"]
    E2 = ["RULE r16 | IF hydraulic_performance_drop AND current_high | THEN fault impeller_blockage | PRIORITY 3 | CF 0.7"]
    E3 = ["RULE r22 | IF vibration_high AND flow_low | THEN fault impeller_blockage | PRIORITY 3 | CF 0.5"]
    for title, ed in (('EDIT 1  add r21 (motor_overload also when flow is low)', E1), ('EDIT 2  edit r16: drop "NOT crackling_noise" and lower CF', E2), ('EDIT 3  add broad rule r22 (vibration AND low flow -> blockage), to fix c27', E3)):
        print('\n' + title); print('   ' + ed[0])
        for st in ('specificity', 'priority'): run_ka(ed, st)
