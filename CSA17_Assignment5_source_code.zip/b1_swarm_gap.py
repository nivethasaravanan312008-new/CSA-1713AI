"""A2.4 configuration (b): wall with a single gap, left half already marked (prediction: drones get trapped - REFUTED)."""
import numpy as np, b1_swarm as S
def make(seed):
    free=np.ones((5,5),bool); free[0:4,2]=False
    sw=S.Swarm(3,free,seed,starts=[(1,0),(1,1),(1,2)],trace=True)
    sw.unm[:, :2]=False; sw.covered_cnt=int((free & ~sw.unm).sum())
    for i in range(3): sw.head[i]=(1,1)
    return sw
res=[]
for sd in range(30):
    sw=make(sd); gap=None
    while sw.t<150 and sw.covered_cnt<sw.total:
        sw.step()
        if gap is None and any(p==(2,4) for p in sw.pos): gap=sw.t
    res.append((gap,sw.covered_cnt/sw.total))
g=[r[0] for r in res if r[0] is not None]
print(f'reached gap: {len(g)}/30, median step {np.median(g)}, max {max(g)}; full coverage {sum(r[1]>=1 for r in res)}/30')
