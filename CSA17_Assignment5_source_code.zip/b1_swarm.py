"""
b1_swarm.py  -  Tasks A2 / B1.3 / B1.4
Decentralised swarm coverage (flood search) on a W x H grid.
Per-agent local rule (stigmergy + separation + inertia):
  1. sense pheromone marks ("already observed") within radius R_TARGET and pick the nearest unmarked free cell,
     penalising targets that are within 2 cells of a neighbouring drone (SEPARATION);
  2. if none, look at the 4 quadrants within R_SNIFF and head to the quadrant with most unmarked cells (GRADIENT);
  3. if none, keep the current heading and bounce off walls (INERTIA).
Neighbour information needed: positions of drones within COMM radius only. No controller, no global map.
A centralised baseline (greedy global assignment, single controller) is included for the A2.1 diagnosis.
"""
import math, random, time
import numpy as np

W = H = 40
T_MAX, BATTERY, TARGET_COV = 150, 100, 0.90
R_TARGET, R_SNIFF, COMM = 3, 6, 5
KING = [(dx, dy) for dx in (-1, 0, 1) for dy in (-1, 0, 1) if (dx, dy) != (0, 0)]
OFFS = sorted([(dx, dy) for dx in range(-R_TARGET, R_TARGET + 1) for dy in range(-R_TARGET, R_TARGET + 1) if (dx, dy) != (0, 0)],
              key=lambda o: (max(abs(o[0]), abs(o[1])), abs(o[0]) + abs(o[1]), o))

def make_world(seed, w=W, h=H, density=0.08):
    rng = np.random.default_rng(1000 + seed)
    nofly = rng.random((h, w)) < density
    nofly[0:3, 0:w] = False                         # 3-row staging strip along the south edge is free
    return ~nofly                                   # free[y, x]

class Swarm:
    def __init__(s, n, free, seed, fail_frac=0.0, mode='swarm', ctrl_fail_at=None, trace=False, starts=None):
        s.n, s.free, s.mode, s.trace = n, free, mode, trace
        s.h, s.w = free.shape
        s.rng, s.py = np.random.default_rng(seed), random.Random(seed)
        s.unm = free.copy()                         # unmarked free cells (pheromone absent)
        s.total = int(free.sum()); s.covered_cnt = 0
        if starts is None:
            cells = [(x, y) for y in (0, 1, 2) for x in range(s.w)]
            s.py.shuffle(cells); starts = cells[:n]
        s.pos = [tuple(c) for c in starts]
        s.head = [(1, 1) if s.py.random() < .5 else (-1, 1) for _ in range(n)]
        s.alive = [True] * n; s.bat = [BATTERY] * n; s.moves = [0] * n
        s.wasted = 0; s.total_moves = 0; s.dec_time = 0.0; s.dec_count = 0
        s.msgs = 0; s.max_node_msgs = 0; s.ctrl_fail_at = ctrl_fail_at
        # failures: k drones die at random times in [5,60]
        if n == 1: k = 1 if (fail_frac > 0 and s.py.random() < fail_frac) else 0
        else: k = math.ceil(fail_frac * n) if fail_frac > 0 else 0
        s.fail_t = {i: s.py.randint(5, 60) for i in s.py.sample(range(n), k)}
        s.cov_curve = []; s.t = 0; s.log = []
        for i in range(n): s.observe(i)
        s.cov_curve.append(s.covered_cnt / s.total)
    def observe(s, i):
        x, y = s.pos[i]; y0, y1, x0, x1 = max(0, y - 1), min(s.h, y + 2), max(0, x - 1), min(s.w, x + 2)
        new = int(s.unm[y0:y1, x0:x1].sum()); s.unm[y0:y1, x0:x1] = False; s.covered_cnt += new
        return new
    def free_cell(s, c, occ):
        return 0 <= c[0] < s.w and 0 <= c[1] < s.h and s.free[c[1], c[0]] and c not in occ
    # ---- the local rule ---------------------------------------------------------------
    def choose_target(s, i, nbrs):
        x, y = s.pos[i]; best = None; found = 0
        for dx, dy in OFFS:
            cx, cy = x + dx, y + dy
            if 0 <= cx < s.w and 0 <= cy < s.h and s.unm[cy, cx]:
                d = max(abs(dx), abs(dy))
                pen = 2.0 * sum(1 for (nx, ny) in nbrs if max(abs(nx - cx), abs(ny - cy)) <= 2)
                sc = d + pen + 0.01 * s.py.random()
                if best is None or sc < best[0]: best = (sc, (cx, cy))
                found += 1
                if found >= 8: break
        if best: return best[1], 'target'
        r = R_SNIFF; q = {}
        for qx, qy in ((1, 1), (-1, 1), (1, -1), (-1, -1)):
            xs = slice(x, min(s.w, x + r + 1)) if qx > 0 else slice(max(0, x - r), x + 1)
            ys = slice(y, min(s.h, y + r + 1)) if qy > 0 else slice(max(0, y - r), y + 1)
            q[(qx, qy)] = int(s.unm[ys, xs].sum())
        m = max(q.values())
        if m > 0:
            dirs = [k for k, v in q.items() if v == m]; d = s.py.choice(dirs)
            return (x + d[0] * 2, y + d[1] * 2), 'gradient'
        hx, hy = s.head[i]
        if not (0 <= x + hx < s.w): hx = -hx
        if not (0 <= y + hy < s.h): hy = -hy
        s.head[i] = (hx, hy)
        return (x + hx * 2, y + hy * 2), 'inertia'
    def step_toward(s, i, tgt, occ):
        x, y = s.pos[i]; sx = (tgt[0] > x) - (tgt[0] < x); sy = (tgt[1] > y) - (tgt[1] < y)
        cands = [(sx, sy), (sx, 0), (0, sy)]
        s.py.shuffle(cands[1:])
        for dx, dy in cands:
            if (dx, dy) != (0, 0) and s.free_cell((x + dx, y + dy), occ): return (x + dx, y + dy)
        opts = [(x + dx, y + dy) for dx, dy in KING if s.free_cell((x + dx, y + dy), occ)]
        return s.py.choice(opts) if opts else (x, y)
    def decide_swarm(s, i, occ, P):
        t0 = time.perf_counter()
        d = np.abs(P - P[i]).max(1); idx = np.where((d <= COMM) & (d > 0))[0]
        nb = [s.pos[j] for j in idx if s.alive[j]]
        s.msgs += len(nb); s.max_node_msgs = max(s.max_node_msgs, len(nb))
        tgt, kind = s.choose_target(i, nb); new = s.step_toward(i, tgt, occ)
        s.dec_time += time.perf_counter() - t0; s.dec_count += 1
        return new, tgt, kind
    def decide_central(s, assign, i, occ):
        t0 = time.perf_counter(); tgt = assign.get(i)
        new = s.step_toward(i, tgt, occ) if tgt else s.pos[i]
        s.dec_time += time.perf_counter() - t0; s.dec_count += 1
        return new, tgt, 'assigned'
    def central_assign(s):
        ys, xs = np.nonzero(s.unm); taken = set(); assign = {}
        if len(xs) == 0: return assign
        for i in range(s.n):
            if not s.alive[i]: continue
            d = np.maximum(np.abs(xs - s.pos[i][0]), np.abs(ys - s.pos[i][1])).astype(float)
            for k in taken: d[k] = 1e9
            k = int(np.argmin(d))
            if d[k] < 1e9: assign[i] = (int(xs[k]), int(ys[k])); taken.add(k)
        return assign
    def step(s):
        s.t += 1
        for i, ft in s.fail_t.items():
            if s.t == ft: s.alive[i] = False
        order = [i for i in range(s.n) if s.alive[i] and s.bat[i] > 0]; s.py.shuffle(order)
        occ = {s.pos[i] for i in range(s.n) if s.alive[i]}
        P = np.array(s.pos)
        ctrl_up = s.mode == 'central' and (s.ctrl_fail_at is None or s.t < s.ctrl_fail_at)
        if s.mode == 'central':
            if ctrl_up:
                assign = s.central_assign(); s.msgs += 2 * len(order); s.max_node_msgs = max(s.max_node_msgs, 2 * len(order))
            else: assign = {}
        row = []
        for i in order:
            if s.mode == 'swarm': new, tgt, kind = s.decide_swarm(i, occ, P)
            else: new, tgt, kind = s.decide_central(assign, i, occ)
            occ.discard(s.pos[i])
            moved = new != s.pos[i]; s.pos[i] = new; occ.add(new)
            if moved: s.bat[i] -= 1; s.moves[i] += 1; s.total_moves += 1
            gain = s.observe(i)
            if moved and gain == 0: s.wasted += 1
            row.append((i, new, tgt, kind, gain))
        s.cov_curve.append(s.covered_cnt / s.total)
        if s.trace: s.log.append((s.t, row, s.covered_cnt))
    def run(s):
        while s.t < T_MAX and s.covered_cnt / s.total < 1.0: s.step()
        while len(s.cov_curve) < T_MAX + 1: s.cov_curve.append(s.cov_curve[-1])
        c = np.array(s.cov_curve); hit = np.where(c >= TARGET_COV)[0]
        return dict(success=bool(len(hit)), t90=int(hit[0]) if len(hit) else None, final_cov=float(c[-1]),
                    redundancy=s.wasted / max(1, s.total_moves), moves=s.total_moves,
                    per_drone_batt=np.mean([m for m, a in zip(s.moves, s.alive) if a] or [0]) / BATTERY,
                    lat_us=1e6 * s.dec_time / max(1, s.dec_count), curve=c, msgs_per_step=s.msgs / max(1, s.t),
                    max_node_msgs=s.max_node_msgs)

def experiment(seeds=30, Ns=(1, 5, 10, 25, 50), fails=(0.0, 0.1, 0.3)):
    R = {}
    for n in Ns:
        for f in fails:
            R[(n, f)] = [Swarm(n, make_world(sd), sd, f).run() for sd in range(seeds)]
    return R

def summarize(rs, key):
    v = [r[key] for r in rs if r[key] is not None]; return (float(np.mean(v)), float(np.std(v))) if v else (float('nan'), 0)

if __name__ == '__main__':
    t0 = time.time(); R = experiment(); print(f'# experiment wall time {time.time()-t0:.1f}s')
    print('=' * 100); print(f'TASK B1.4  single drone vs swarm  | grid {W}x{H} | 30 seeds | T_max={T_MAX} | battery={BATTERY} moves | success = coverage>={TARGET_COV:.0%}'); print('=' * 100)
    print(f"{'N':>3} {'fail':>5} | {'success':>8} {'final cov %':>14} {'T90 (steps)':>12} {'redundancy':>11} {'moves/drone%':>13} {'total moves':>12} {'latency us':>11}")
    for (n, f), rs in R.items():
        sr = np.mean([r['success'] for r in rs]); fc = summarize(rs, 'final_cov'); t9 = summarize(rs, 'final_cov' if False else 't90')
        rd = summarize(rs, 'redundancy'); pb = summarize(rs, 'per_drone_batt'); mv = summarize(rs, 'moves'); la = summarize(rs, 'lat_us')
        t9s = f'{t9[0]:.1f}' if t9[0] == t9[0] else '-'
        print(f"{n:>3} {f:>5.0%} | {sr:>8.0%} {100*fc[0]:>9.1f}±{100*fc[1]:<4.1f} {t9s:>12} {rd[0]:>11.3f} {100*pb[0]:>13.1f} {mv[0]:>12.0f} {la[0]:>11.1f}")
    print('\nEND of B1.4 table')
