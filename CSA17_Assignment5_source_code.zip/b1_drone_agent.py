"""
b1_drone_agent.py  -  Task A1 / B1.1 / B1.2
Layered (reactive safety + deliberative planner) parcel-delivery drone on a grid.
Agent logic (LayeredDroneAgent) is separated from the simulator (World) and from I/O (run_scenario).
Coordinates are (x, y); N = y+1, E = x+1.  All randomness is seeded.
"""
import heapq, random

DIRS = {'E': (1, 0), 'W': (-1, 0), 'N': (0, 1), 'S': (0, -1)}
ORDER = ['E', 'W', 'N', 'S']          # fixed neighbour order -> deterministic tie-breaking
RESERVE = 3                           # battery safety margin (moves)

def manhattan(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])

# ------------------------------------------------------------------ simulator
class World:
    def __init__(s, w, h, nofly, base, goal, battery, appear=None, wind_p=0.0, dyn_p=0.0, seed=0):
        s.w, s.h, s.nofly, s.base, s.goal = w, h, set(nofly), base, goal
        s.pos, s.battery, s.t = base, battery, 0
        s.appear = dict(appear or {})          # {time: cell that suddenly becomes blocked}
        s.dyn, s.rng, s.wind_p, s.dyn_p = set(), random.Random(seed), wind_p, dyn_p
        s.collisions, s.landed, s.delivered, s.crashed, s.brakes = 0, False, False, False, 0
        s.drift_events = 0
    def inb(s, c):  return 0 <= c[0] < s.w and 0 <= c[1] < s.h
    def blocked(s, c): return (not s.inb(c)) or c in s.nofly or c in s.dyn
    def start_step(s):
        if s.t in s.appear: s.dyn.add(s.appear[s.t])
        if s.dyn_p and s.rng.random() < s.dyn_p:             # random sudden obstacle near the drone
            cand = [(s.pos[0] + dx, s.pos[1] + dy) for dx, dy in DIRS.values()]
            cand = [c for c in cand if s.inb(c) and not s.blocked(c) and c not in (s.base, s.goal)]
            if cand: s.dyn.add(s.rng.choice(cand))
    def percept(s):
        adj = {(s.pos[0] + dx, s.pos[1] + dy) for dx, dy in DIRS.values()}
        return {'t': s.t, 'pos': s.pos, 'battery': s.battery,
                'blocked_adjacent': {c for c in adj if s.inb(c) and (c in s.dyn or c in s.nofly)}}
    def act(s, a):
        if a in DIRS:
            dx, dy = DIRS[a]
            if s.wind_p and s.rng.random() < s.wind_p:        # wind drift: executed move is random
                dx, dy = DIRS[s.rng.choice(ORDER)]; s.drift_events += 1
            nxt = (s.pos[0] + dx, s.pos[1] + dy)
            if s.blocked(nxt):          # flight-controller proximity brake vetoes a move into a sensed blocked cell
                s.brakes += 1
            else: s.pos = nxt
            s.battery -= 1
        elif a == 'DROP':
            s.delivered = s.delivered or (s.pos == s.goal); s.battery -= 1
        elif a == 'HOVER':
            s.battery -= 1
        elif a == 'LAND':
            s.landed = True
        if s.battery < 0 and not s.landed: s.crashed = True
        s.t += 1
    def outcome(s):
        if s.crashed: return 'FAILURE (collision/battery)'
        if s.landed and s.pos == s.base and s.delivered: return 'SUCCESS (delivered, landed at base)'
        if s.landed and s.pos == s.base: return 'SAFE ABORT (not delivered, landed at base)'
        if s.landed: return 'EMERGENCY LANDING (safe cell, away from base)'
        return 'TIMEOUT'

# ------------------------------------------------------------------ agent
class LayeredDroneAgent:
    """Percepts -> internal state -> [reactive layer | deliberative layer] -> action."""
    def __init__(s, w, h, nofly, base, goal):
        s.w, s.h, s.nofly, s.base, s.goal = w, h, set(nofly), base, goal
        s.known = set()            # dynamically discovered blocked cells
        s.mode = 'DELIVER'         # DELIVER | RTB
        s.pos, s.battery, s.last_move, s.plan = base, 0, None, []
        s.delivered = False
    def blocked(s, c):
        return not (0 <= c[0] < s.w and 0 <= c[1] < s.h) or c in s.nofly or c in s.known
    def astar(s, start, target):
        if s.blocked(target): return None
        pq, g, par, cnt = [(manhattan(start, target), 0, 0, start)], {start: 0}, {}, 0
        while pq:
            f, negg, _, cur = heapq.heappop(pq)
            if cur == target:
                path = []
                while cur != start: path.append(cur); cur = par[cur]
                return path[::-1]
            for d in ORDER:
                nxt = (cur[0] + DIRS[d][0], cur[1] + DIRS[d][1])
                if s.blocked(nxt): continue
                ng = g[cur] + 1
                if ng < g.get(nxt, 1e9):
                    g[nxt], par[nxt] = ng, cur; cnt += 1
                    heapq.heappush(pq, (ng + manhattan(nxt, target), -ng, cnt, nxt))
        return None
    @staticmethod
    def dir_to(a, b):
        for d, (dx, dy) in DIRS.items():
            if (a[0] + dx, a[1] + dy) == b: return d
    def decide(s, p):
        # ---- state update
        s.pos, s.battery = p['pos'], p['battery']
        if s.plan and s.plan[0] == s.pos: s.plan = s.plan[1:]      # last step executed as planned
        else: s.plan = []                                          # drift / first step / replan forced
        intended = s.plan[0] if s.plan else None                   # next cell the committed plan will enter
        newly = p['blocked_adjacent'] - s.known - s.nofly
        s.known |= p['blocked_adjacent']
        home = s.astar(s.pos, s.base) if s.pos != s.base else []
        dh = len(home) if home is not None else 10 ** 6
        # ---- REACTIVE SAFETY LAYER (highest priority)
        if s.mode == 'RTB' and s.pos == s.base:
            return 'LAND', 'REACTIVE', 'R0 at base -> land', dh
        if s.battery < dh and s.pos != s.base:
            return 'LAND', 'REACTIVE', 'R1 cannot reach base (batt<dist_home) -> emergency land', dh
        if intended is not None and intended in newly:
            best = None
            for d in ['N', 'S', 'E', 'W']:
                c = (s.pos[0] + DIRS[d][0], s.pos[1] + DIRS[d][1])
                if s.blocked(c): continue
                if s.last_move and DIRS[d] == (-DIRS[s.last_move][0], -DIRS[s.last_move][1]): continue
                tgt = s.goal if s.mode == 'DELIVER' else s.base
                sc = manhattan(c, tgt)
                if best is None or sc < best[0]: best = (sc, d)
            s.plan = []
            if best:
                s.last_move = best[1]
                return best[1], 'REACTIVE', f'R2 obstacle ahead at {sorted(newly)[0]} -> sidestep', dh
            return 'HOVER', 'REACTIVE', 'R2 no free side cell -> hover', dh
        # ---- DELIBERATIVE LAYER (mission manager + A* planner)
        note = ''
        if s.mode == 'DELIVER' and s.pos == s.goal:
            s.mode, s.delivered = 'RTB', True
            return 'DROP', 'DELIBERATIVE', 'D1 at goal -> drop parcel, switch to RTB', dh
        if s.mode == 'DELIVER' and s.battery <= dh + RESERVE:
            s.mode = 'RTB'; note = f'D2 battery {s.battery} <= dist_home {dh} + reserve {RESERVE} -> abort, RTB; '
        tgt = s.goal if s.mode == 'DELIVER' else s.base
        path = s.astar(s.pos, tgt)
        if path is None and s.mode == 'DELIVER':
            s.mode = 'RTB'; note += 'D3 goal unreachable/blocked -> RTB; '
            tgt, path = s.base, s.astar(s.pos, s.base)
        if path is None:
            return 'LAND', 'REACTIVE', 'R3 no path home -> land at current safe cell', dh
        if not path:
            return 'LAND', 'DELIBERATIVE', 'at target', dh
        d = s.dir_to(s.pos, path[0]); s.plan, s.last_move = path, d
        return d, 'DELIBERATIVE', note + f'D4 follow A* plan to {tgt} (len {len(path)})', dh

def run_scenario(name, world, agent, max_steps=80, verbose=True):
    log = []
    while not world.landed and not world.crashed and world.t < max_steps:
        world.start_step()
        p = world.percept()
        a, layer, note, dh = agent.decide(p)
        log.append((p['t'], p['pos'], p['battery'], dh, agent.mode, layer, a, note))
        world.act(a)
    if verbose:
        print(f"{'t':>2} {'pos':<7}{'batt':>4} {'d_home':>6} {'mode':<8}{'layer':<13}{'action':<6} note")
        for t, pos, b, dh, m, l, a, n in log:
            print(f"{t:>2} {str(pos):<7}{b:>4} {dh:>6} {m:<8}{l:<13}{a:<6} {n}")
        print(f"-> outcome: {world.outcome()} | steps={world.t} | battery_left={world.battery} | "
              f"collisions={world.collisions} | brake_events={world.brakes} | delivered={world.delivered}")
    return log

def build(battery, goal=(6, 0), appear=None, nofly=(), wind_p=0.0, dyn_p=0.0, seed=0, start=None):
    w = World(10, 10, nofly, (0, 0), goal, battery, appear, wind_p, dyn_p, seed)
    if start: w.pos = start
    return w, LayeredDroneAgent(10, 10, nofly, (0, 0), goal)

if __name__ == '__main__':
    print('=' * 92); print('TASK B1.1  validation of the layered drone agent (10x10 grid, base (0,0), goal (6,0))'); print('=' * 92)
    print('\n[S1] NORMAL FLIGHT  battery=30, no obstacle'); w, a = build(30); run_scenario('S1', w, a)
    print('\n[S2] SUDDEN OBSTACLE  battery=30, cell (4,0) becomes blocked at t=3'); w, a = build(30, appear={3: (4, 0)}); run_scenario('S2', w, a)
    print('\n[S3] BOUNDARY: LOW BATTERY + OBSTACLE (the A1.5 trace)  battery=12, (4,0) blocked at t=3')
    w, a = build(12, appear={3: (4, 0)}); run_scenario('S3', w, a)
    print('\n[S4] BOUNDARY: GOAL BLOCKED  battery=30, goal cell (6,0) becomes blocked at t=4')
    w, a = build(30, appear={4: (6, 0)}); run_scenario('S4', w, a)
    print('\n[S5] BOUNDARY: BATTERY EXHAUSTED IN FLIGHT  drone found at (5,0) with battery=2 (needs 5 to return)')
    w, a = build(2, start=(5, 0)); run_scenario('S5', w, a)
    print('\n[S6] NO-FLY ZONE  battery=40, no-fly wall x=3,y=0..3 ; drone must plan around it')
    w, a = build(40, nofly=[(3, 0), (3, 1), (3, 2), (3, 3)]); run_scenario('S6', w, a)
    print('\n' + '=' * 92); print('Robustness: 30 seeds, wind drift p=0.15 and random sudden obstacles p=0.10, battery=40'); print('=' * 92)
    res = {}; coll = 0; brk = 0
    for seed in range(30):
        w, a = build(40, nofly=[(3, 0), (3, 1), (3, 2), (3, 3)], wind_p=0.15, dyn_p=0.10, seed=seed)
        run_scenario('R', w, a, verbose=False); o = w.outcome().split(' (')[0]
        res[o] = res.get(o, 0) + 1; coll += w.collisions; brk += w.brakes
    for k, v in sorted(res.items()): print(f'  {k:<18}: {v:>2}/30')
    print(f'  total collisions   : {coll}   | proximity-brake events (wind pushed toward a blocked cell): {brk}')
