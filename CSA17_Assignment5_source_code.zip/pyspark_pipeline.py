"""pyspark_pipeline.py - Task A4 / B3.3 in real PySpark.  WRITTEN BUT NOT EXECUTED in the build sandbox (no Spark/Java available offline).
Run:  spark-submit pyspark_pipeline.py 1000000 8      (records, partitions)"""
import sys, time, math
from pyspark import SparkContext
import numpy as np
N, P = int(sys.argv[1]), int(sys.argv[2]); HOSTS = 1000
W = np.array([.9, 1.1, -0.4, 1.3, .7, 1.0, .5, -.6], dtype=np.float32)
def gen(i):                                              # deterministic per partition -> lineage can recompute it
    m = N // P + (1 if i < N % P else 0); r = np.random.default_rng(1000 + i)
    host = r.integers(0, HOSTS, m); f = r.standard_normal((m, 8), dtype=np.float32); f[:, 0] *= (1 + (host % 7 == 0) * 2)
    return [(int(h), x) for h, x in zip(host, f)]
def merge(a, b): return (a[0] + b[0], a[1] + b[1], a[2] + b[2], max(a[3], b[3]))
sc = SparkContext(appName='ids-a4-pipeline')
src = sc.parallelize(range(P), P).flatMap(gen)                       # source RDD
feat = src.map(lambda r: (r[0], np.clip(r[1], -6, 6)))               # narrow: feature extraction
feat.cache()                                                         # reused by action 2
pairs = feat.map(lambda r: (r[0], (lambda s: (1, float(s), float(s * s), float(s)))(r[1] @ W)))   # narrow: score
agg = pairs.reduceByKey(merge, P)                                    # WIDE: one shuffle
stats = agg.mapValues(lambda v: (v[1] / v[0], v[3], math.sqrt(max(v[2] / v[0] - (v[1] / v[0]) ** 2, 0))))
t0 = time.time(); top10 = stats.takeOrdered(10, key=lambda kv: -kv[1][2]); a1 = time.time() - t0   # ACTION 1
t0 = time.time(); flagged = feat.filter(lambda r: float(r[1] @ W) > 3.0).count(); a2 = time.time() - t0  # ACTION 2
print(f'records={N} partitions={P} action1={a1:.2f}s action2={a2:.2f}s flagged={flagged}')
print(stats.toDebugString().decode())                                # lineage
for k, v in top10: print(k, v)
