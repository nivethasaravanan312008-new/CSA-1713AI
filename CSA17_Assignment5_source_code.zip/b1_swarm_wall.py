"""A2.4 failure configuration: 'single remaining cell' convergence (redundant coverage + clustering).
The prediction is written in the report BEFORE this file was run."""
import numpy as np, b1_swarm as S
def gm(sw):
    rows=[]
    for y in range(sw.h-1,-1,-1):
        r=''
        for x in range(sw.w):
            d=[i for i,p in enumerate(sw.pos) if p==(x,y)]
            r+= (f'D{d[0]}' if d else (' X' if not sw.free[y,x] else (' .' if sw.unm[y,x] else ' #')))+' '
        rows.append('   '+r)
    return '\n'.join(rows)
def make(seed, n=3):
    free=np.ones((5,5),bool)
    starts=[(0,0),(1,0),(0,1)][:n]
    sw=S.Swarm(n,free,seed,starts=starts,trace=True)
    sw.unm[:]=False; sw.unm[4,4]=True                      # everything marked except the far corner (4,4)
    sw.covered_cnt=24
    for i in range(n): sw.head[i]=(1,1)
    return sw
if __name__=='__main__':
    sw=make(1); print('A2.4  single-remaining-cell configuration, seed 1 (# marked, . unmarked, Dk drone)')
    print('t=0 covered=%d/%d'%(sw.covered_cnt,sw.total)); print(gm(sw))
    while sw.covered_cnt<sw.total and sw.t<12:
        sw.step(); t,row,cov=sw.log[-1]
        print(f't={t} '+'; '.join(f'D{i}->{p}[{k}]' for i,p,tg,k,g in row)+f'  covered={cov}/{sw.total}  moves so far={sw.total_moves}'); print(gm(sw))
    print(f'RESULT: finished at t={sw.t}, total drone moves={sw.total_moves}, moves that revealed a new cell={sw.total_moves-sw.wasted}, wasted-move ratio={sw.wasted/max(1,sw.total_moves):.2f}')
    print('\nSame configuration, 1 drone vs 3 drones, 30 seeds (mean):')
    for n in (1,3):
        T=[];M=[]
        for sd in range(30):
            s=make(sd,n)
            while s.covered_cnt<s.total and s.t<50: s.step()
            T.append(s.t);M.append(s.total_moves)
        print(f'  N={n}: steps to finish = {np.mean(T):.1f}, total moves = {np.mean(M):.1f}')
