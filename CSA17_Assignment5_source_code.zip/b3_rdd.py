"""
b3_rdd.py - Task A4 / B3.3.  PySpark is NOT installable in the offline sandbox, so the Task A4 pipeline is run on MiniRDD, a small
emulator that reproduces RDD semantics: lazy transformations, narrow vs wide dependencies, shuffle counting, cache(), lineage and
partition recomputation.  The identical pipeline in real PySpark is in pyspark_pipeline.py (written, NOT executed here).
Machine: 1 CPU core -> partitions cannot give parallel speed-up here; that is part of the finding.
"""
import numpy as np, time, pickle
HOSTS = 1000
class RDD:
    SHUFFLES = 0
    def __init__(s, parent=None, kind='source', fn=None, nparts=1, name=''):
        s.parent, s.kind, s.fn, s.n, s.name = parent, kind, fn, nparts, name
        s.cached, s.store, s._shuf, s.hits, s.computed = False, {}, None, 0, 0
    def cache(s): s.cached = True; return s
    def unpersist(s): s.cached = False; s.store = {}; return s
    # transformations (lazy: they only build lineage)
    def map_partitions(s, fn, name='mapPartitions'): return RDD(s, 'narrow', fn, s.n, name)
    def reduce_by_key(s, merge, nparts=None, name='reduceByKey'): r = RDD(s, 'wide', merge, nparts or s.n, name); return r
    def map_values(s, fn, name='mapValues'): return s.map_partitions(lambda it: [(k, fn(v)) for k, v in it], name)
    # evaluation
    def compute(s, i):
        if s.cached and i in s.store: s.hits += 1; return s.store[i]
        s.computed += 1
        if s.kind == 'source': out = s.fn(i, s.n)
        elif s.kind == 'narrow': out = s.fn(s.parent.compute(i))
        else:
            if s._shuf is None:                                   # shuffle: every parent partition must be computed and exchanged
                RDD.SHUFFLES += 1; buckets = [dict() for _ in range(s.n)]
                for j in range(s.parent.n):
                    for k, v in s.parent.compute(j):
                        b = buckets[hash(k) % s.n]; b[k] = s.fn(b[k], v) if k in b else v
                s._shuf = buckets
            out = list(s._shuf[i].items())
        if s.cached: s.store[i] = out
        return out
    def reset_shuffle(s):
        n = s
        while n is not None: n._shuf = None; n = n.parent
    # actions (trigger evaluation)
    def collect(s): s.reset_shuffle(); return [x for i in range(s.n) for x in s.compute(i)]
    def take_ordered(s, k, key): return sorted(s.collect(), key=key)[:k]
    def count_where(s, pred_fn):
        return sum(pred_fn(s.compute(i)) for i in range(s.n))
    def lineage(s):
        L, n = [], s
        while n is not None: L.append(f'({n.n}) {n.name} [{n.kind}{" ,SHUFFLE" if n.kind=="wide" else ""}{" ,cached" if n.cached else ""}]'); n = n.parent
        return '\n'.join('  ' * k + ('+- ' if k else '') + l for k, l in enumerate(L))

# ---- A4-style pipeline over IDS flow records (hostId, features) --------------------------------------------------------------
W = np.array([.9, 1.1, -0.4, 1.3, .7, 1.0, .5, -.6], np.float32)   # stage-1 style linear anomaly score (compressed model)
def make_source(total):
    def gen(i, P):
        m = total // P + (1 if i < total % P else 0); r = np.random.default_rng(1000 + i)
        host = r.integers(0, HOSTS, m).astype(np.int32); f = r.standard_normal((m, 8), dtype=np.float32)
        f[:, 0] *= (1 + (host % 7 == 0) * 2)                 # a few 'noisy' hosts have larger variance
        return host, f
    return gen
def extract(part):                                            # narrow: feature extraction (log/clip)
    host, f = part; return host, np.clip(f, -6, 6) * 1.0
def score_and_combine(part):                                  # narrow + map-side combine (n,sum,sumsq,max per host)
    host, f = part; s = f @ W
    n = np.bincount(host, minlength=HOSTS); sm = np.bincount(host, s, HOSTS); sq = np.bincount(host, s * s, HOSTS)
    mx = np.full(HOSTS, -1e9, np.float32); np.maximum.at(mx, host, s) if len(host) < 2000 else None
    if len(host) >= 2000:
        o = np.argsort(host, kind='stable'); h = host[o]; ss = s[o]; st = np.r_[0, np.flatnonzero(np.diff(h)) + 1]; mx[h[st]] = np.maximum.reduceat(ss, st)
    return [(int(k), (int(n[k]), float(sm[k]), float(sq[k]), float(mx[k]))) for k in np.flatnonzero(n)]
merge = lambda a, b: (a[0] + b[0], a[1] + b[1], a[2] + b[2], max(a[3], b[3]))
def build(total, P, cache):
    src = RDD(None, 'source', make_source(total), P, 'parallelize(generate flows)')
    feat = src.map_partitions(extract, 'map_partitions(extract_features)')
    if cache: feat.cache()
    agg = feat.map_partitions(score_and_combine, 'map_partitions(score+combine)').reduce_by_key(merge, P, 'reduceByKey(merge stats)')
    stats = agg.map_values(lambda v: (v[1] / v[0], v[3], max(v[2] / v[0] - (v[1] / v[0]) ** 2, 0) ** .5), 'mapValues(mean,max,std)')
    return src, feat, stats
def flagged(feat):                                              # second action reusing the feature RDD
    n = 0
    for i in range(feat.n):
        host, f = feat.compute(i); n += int(((f @ W) > 3.0).sum())
    return n
def run(total, P, cache):
    RDD.SHUFFLES = 0; src, feat, stats = build(total, P, cache)
    t0 = time.perf_counter(); top = stats.take_ordered(10, key=lambda kv: -kv[1][2]); a1 = time.perf_counter() - t0; sh1 = RDD.SHUFFLES
    t0 = time.perf_counter(); nf = flagged(feat); a2 = time.perf_counter() - t0
    return a1, a2, sh1, RDD.SHUFFLES - sh1, top, nf, feat

if __name__ == '__main__':
    print('=' * 100); print('TASK A4/B3.3  RDD pipeline scaling (MiniRDD emulator, 1 CPU core, float32 features, 1000 hosts)'); print('=' * 100)
    src, feat, stats = build(1000, 4, True); print('LINEAGE of the result RDD (nothing has been computed yet - transformations are lazy):'); print(stats.lineage())
    print(f'computed partitions so far: {src.computed + feat.computed} (lazy)\n')
    rows = []
    print(f"{'records':>10}{'parts':>6}{'cache':>6} | {'action1 s':>10}{'action2 s':>10}{'total s':>9}{'shuffles a1':>12}{'shuffles a2':>12}{'cache hits':>11}{'rec/s (a1)':>12}")
    for total in (10**5, 10**6, 10**7):
        for P in (1, 2, 4, 8):
            for cache in (False, True):
                if total == 10**7 and cache and P in (2, 8): continue
                reps = 3 if total < 10**7 else 1; best = None
                for _ in range(reps):
                    a1, a2, s1, s2, top, nf, feat = run(total, P, cache)
                    if best is None or a1 + a2 < best[0] + best[1]: best = (a1, a2, s1, s2, feat.hits)
                a1, a2, s1, s2, hits = best; rows.append((total, P, cache, a1, a2, s1, s2, hits))
                print(f'{total:>10,}{P:>6}{str(cache):>6} | {a1:>10.3f}{a2:>10.3f}{a1+a2:>9.3f}{s1:>12}{s2:>12}{hits:>11}{total/a1:>12,.0f}')
                del feat
    # lineage recovery demo
    print('\nLINEAGE RECOVERY: 10^6 records, 8 partitions, cached feature RDD; partition 3 is "lost" (evicted) and rebuilt from lineage')
    RDD.SHUFFLES = 0; src, feat, stats = build(10**6, 8, True); top0 = stats.take_ordered(10, key=lambda kv: -kv[1][2])
    h0 = feat.store[3][1].sum(); del feat.store[3]; c0 = feat.computed; src.computed = 0
    t0 = time.perf_counter(); host, f = feat.compute(3); rec_t = time.perf_counter() - t0
    print(f'  recomputed partition 3 only: source partitions recomputed = {src.computed} (of 8), time = {rec_t*1000:.1f} ms, identical checksum = {np.isclose(h0, f.sum())}')
    print('  top-10 noisiest hosts (host, mean score, max score, std):'); [print(f'   host {k:>4}  mean={v[0]:+.3f} max={v[1]:.2f} std={v[2]:.3f}') for k, v in top0]
    pickle.dump(rows, open('out/rdd_rows.pkl', 'wb'))
