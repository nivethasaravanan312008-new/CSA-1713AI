"""
b3_ids.py - Task A5 / B3.1 / B3.2 / B3.4 : AI-based intrusion detection, full model vs edge model.
DATA: no internet in the build sandbox, so the public NSL-KDD files (Tavallaee et al., 2009) could not be downloaded.
We therefore generate a SYNTHETIC, time-ordered flow dataset that follows the NSL-KDD feature schema (21 of its fields + one
timing feature) and attack families (DoS, Probe, R2L). A 'subtype' tag is kept ONLY for error analysis, never for training.
Splits are time-ordered (first 70% of time = train, last 30% = test); a botnet-beaconing family exists only after t=0.85.
"""
import numpy as np, time, pickle, io, sys
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score, roc_auc_score,
                             average_precision_score, confusion_matrix)

FEATS = ['duration', 'src_bytes', 'dst_bytes', 'count', 'srv_count', 'serror_rate', 'rerror_rate', 'same_srv_rate',
         'diff_srv_rate', 'dst_host_count', 'dst_host_srv_count', 'dst_host_same_srv_rate', 'dst_host_serror_rate',
         'num_failed_logins', 'logged_in', 'num_compromised', 'root_shell', 'hot', 'is_tcp', 'is_udp', 'iat_cv']

def generate(n=50000, seed=7):
    rng = np.random.default_rng(seed)
    t = np.sort(rng.random(n))                                   # timestamps in [0,1)
    u = rng.random(n)
    sub = np.empty(n, dtype=object)
    p_dos = 0.10 + 0.10 * np.sin(6 * t) ** 2                     # attack mix varies over time
    cuts = [('normal', 0.0)]
    # families chosen by thresholds on u
    pn, pf, pd, pp, ps, pr = 0.60, 0.06, None, 0.08, 0.025, 0.05
    sub[:] = 'normal'
    c1 = pn; sub[u >= c1] = 'flash_crowd'
    c2 = c1 + pf; sub[u >= c2] = 'dos'
    c3 = c2 + 0.14; sub[u >= c3] = 'probe'
    c4 = c3 + pp; sub[u >= c4] = 'slow_probe'
    c5 = c4 + ps; sub[u >= c5] = 'r2l'
    c6 = c5 + pr                                                 # remainder (~2.5%) = U2R-like rare
    sub[u >= c6] = 'u2r'
    bot = (t > 0.85) & (rng.random(n) < 0.20); sub[bot] = 'botnet'   # unseen family, test period only
    X = np.zeros((n, len(FEATS)))
    L = lambda m, s_: rng.lognormal(m, s_, n)
    idx = {k: np.where(sub == k)[0] for k in set(sub)}
    # --- defaults = normal traffic (with slow drift in bytes)
    drift = 1 + 0.6 * t
    X[:, 0] = L(1.0, 1.4); X[:, 1] = L(6.5, 1.8) * drift; X[:, 2] = L(7.0, 1.8) * drift
    X[:, 3] = rng.poisson(8, n) + 1; X[:, 4] = rng.poisson(6, n) + 1
    X[:, 5] = rng.beta(1, 20, n); X[:, 6] = rng.beta(1, 25, n); X[:, 7] = rng.beta(18, 2, n); X[:, 8] = rng.beta(1.5, 14, n)
    X[:, 9] = rng.integers(1, 120, n); X[:, 10] = rng.integers(1, 120, n); X[:, 11] = rng.beta(14, 2, n); X[:, 12] = rng.beta(1, 18, n)
    X[:, 13] = (rng.random(n) < 0.02) * rng.integers(1, 3, n); X[:, 14] = rng.random(n) < 0.7
    X[:, 15] = (rng.random(n) < 0.01); X[:, 16] = 0; X[:, 17] = rng.poisson(0.05, n)
    tcp = rng.random(n) < 0.8; X[:, 18] = tcp; X[:, 19] = ~tcp
    X[:, 20] = np.where(rng.random(n) < 0.15, rng.uniform(0.02, 0.3, n), rng.lognormal(0.3, 0.5, n))  # automation (NTP, health checks) has regular timing
    def setf(k, j, v):
        ii = idx.get(k, np.array([], int))
        if len(ii): X[ii, j] = v(len(ii))
    G = lambda f: (lambda m: f(m))
    # flash crowd: legit but looks like a flood
    setf('flash_crowd', 3, lambda m: rng.poisson(150, m) + 20); setf('flash_crowd', 4, lambda m: rng.poisson(140, m) + 20)
    setf('flash_crowd', 5, lambda m: rng.beta(2, 8, m)); setf('flash_crowd', 7, lambda m: rng.beta(20, 2, m)); setf('flash_crowd', 14, lambda m: np.ones(m))
    # DoS (SYN flood)
    setf('dos', 0, lambda m: np.zeros(m)); setf('dos', 1, lambda m: np.zeros(m)); setf('dos', 2, lambda m: np.zeros(m))
    setf('dos', 3, lambda m: rng.poisson(250, m) + 30); setf('dos', 4, lambda m: rng.poisson(240, m) + 30)
    setf('dos', 5, lambda m: rng.beta(12, 2, m)); setf('dos', 12, lambda m: rng.beta(12, 2, m)); setf('dos', 14, lambda m: np.zeros(m))
    setf('dos', 20, lambda m: rng.uniform(0.01, 0.2, m))
    # probe (port scan)
    setf('probe', 1, lambda m: rng.lognormal(2.5, .8, m)); setf('probe', 2, lambda m: rng.lognormal(1.5, .8, m))
    setf('probe', 8, lambda m: rng.beta(8, 2, m)); setf('probe', 7, lambda m: rng.beta(2, 8, m)); setf('probe', 9, lambda m: rng.integers(150, 255, m))
    setf('probe', 6, lambda m: rng.beta(4, 6, m)); setf('probe', 14, lambda m: np.zeros(m))
    # slow probe: low and slow, close to normal
    setf('slow_probe', 8, lambda m: rng.beta(3, 9, m)); setf('slow_probe', 9, lambda m: rng.integers(60, 160, m)); setf('slow_probe', 6, lambda m: rng.beta(2, 12, m))
    setf('slow_probe', 1, lambda m: rng.lognormal(4.5, 1.0, m))
    # R2L (password guessing)
    setf('r2l', 13, lambda m: rng.integers(0, 6, m)); setf('r2l', 14, lambda m: (rng.random(m) < 0.25).astype(float)); setf('r2l', 17, lambda m: rng.poisson(1.5, m))
    setf('r2l', 3, lambda m: rng.poisson(3, m) + 1)
    # U2R (rare): root shell / compromised
    setf('u2r', 16, lambda m: (rng.random(m) < 0.7).astype(float)); setf('u2r', 15, lambda m: rng.poisson(2, m)); setf('u2r', 14, lambda m: np.ones(m)); setf('u2r', 17, lambda m: rng.poisson(3, m))
    # botnet beaconing (UNSEEN in training): small periodic flows, normal-looking volume
    setf('botnet', 20, lambda m: rng.uniform(0.01, 0.15, m)); setf('botnet', 1, lambda m: rng.lognormal(5.0, .5, m)); setf('botnet', 2, lambda m: rng.lognormal(5.5, .5, m))
    setf('botnet', 3, lambda m: rng.poisson(2, m) + 1); setf('botnet', 14, lambda m: np.ones(m)); setf('botnet', 0, lambda m: rng.lognormal(0.5, .4, m))
    y = np.isin(sub, ['dos', 'probe', 'slow_probe', 'r2l', 'u2r', 'botnet']).astype(int)
    return t, X.astype(np.float64), y, sub

def split(t, X, y, sub, frac=0.7):
    cut = int(len(t) * frac); return (X[:cut], y[:cut], sub[:cut], t[:cut]), (X[cut:], y[cut:], sub[cut:], t[cut:])

def metrics(y, pred, score):
    tn, fp, fn, tp = confusion_matrix(y, pred).ravel()
    return dict(acc=accuracy_score(y, pred), prec=precision_score(y, pred), rec=recall_score(y, pred), f1=f1_score(y, pred),
                roc=roc_auc_score(y, score), pr=average_precision_score(y, score), cm=(tn, fp, fn, tp))

# ---------------------------------------------------------------- compressed edge model: early-exit cascade
class EdgeCascade:
    """Stage 1: int8-quantised logistic regression on top-k features (exit when confident).
       Stage 2: compact forest (few shallow trees) stored as flat arrays, scalar traversal.  Pure Python/numpy, no sklearn at inference."""
    def __init__(s, Xtr, ytr, imp, k=8, n_trees=12, depth=8, exit_conf=0.93, seed=0):
        s.top = np.argsort(imp)[::-1][:k]; s.exit_conf = exit_conf
        s.mu, s.sd = Xtr[:, s.top].mean(0), Xtr[:, s.top].std(0) + 1e-9
        lr = LogisticRegression(C=1.0, max_iter=500).fit((Xtr[:, s.top] - s.mu) / s.sd, ytr)
        w = lr.coef_[0]; s.wscale = 127 / np.abs(w).max(); s.wq = np.round(w * s.wscale).astype(np.int8)   # int8 weights
        s.b = float(lr.intercept_[0]); s.mu32, s.isd32 = s.mu.astype(np.float32), (1 / s.sd).astype(np.float32)
        rf = RandomForestClassifier(n_estimators=n_trees, max_depth=depth, min_samples_leaf=5, random_state=seed, n_jobs=1).fit(Xtr[:, s.top], ytr)
        s.trees = []
        for e in rf.estimators_:
            tr = e.tree_; val = tr.value[:, 0, :]; p1 = (val[:, 1] / val.sum(1)).astype(np.float32)
            s.trees.append((tr.children_left.astype(np.int16), tr.children_right.astype(np.int16), tr.feature.astype(np.int8), tr.threshold.astype(np.float32), p1))
        s.stage2_calls = 0
    def predict_one(s, x):
        xs = x[s.top]
        z = float(((xs - s.mu32) * s.isd32) @ s.wq) / s.wscale + s.b
        p = 1.0 / (1.0 + np.exp(-z))
        if p >= s.exit_conf or p <= 1 - s.exit_conf: return p, 1
        s.stage2_calls += 1; acc = 0.0
        for L, R, F, T, P in s.trees:
            n = 0
            while L[n] != -1: n = L[n] if xs[F[n]] <= T[n] else R[n]
            acc += P[n]
        return acc / len(s.trees), 2
    def predict_batch(s, X):
        out = [s.predict_one(x) for x in X]; return np.array([o[0] for o in out]), np.array([o[1] for o in out])
    def size_bytes(s):
        sz = s.wq.nbytes + s.mu32.nbytes + s.isd32.nbytes + s.top.nbytes + 8
        for tr in s.trees: sz += sum(a.nbytes for a in tr)
        return sz

def lat_stats(fn, samples, warm=20):
    for x in samples[:warm]: fn(x)
    ts = []
    for x in samples:
        t0 = time.perf_counter(); fn(x); ts.append((time.perf_counter() - t0) * 1e3)
    ts = np.array(ts); return ts.mean(), np.percentile(ts, 95), len(ts) / (ts.sum() / 1e3)

if __name__ == '__main__':
    t, X, y, sub = generate(); (Xtr, ytr, str_, ttr), (Xte, yte, ste, tte) = split(t, X, y, sub)
    print('=' * 100); print('TASK B3.1  intrusion detection - full model (leakage-safe, time-ordered split)'); print('=' * 100)
    print('data source : SYNTHETIC flows following the NSL-KDD schema (Tavallaee et al., 2009); generator seed = 7')
    print(f'records     : {len(t)}   features: {len(FEATS)}   attack share overall: {y.mean():.3f}')
    print(f'split       : train = first 70% of time ({len(ytr)} rows, t in [{ttr.min():.3f},{ttr.max():.3f}]), test = last 30% ({len(yte)} rows, t in [{tte.min():.3f},{tte.max():.3f}])')
    print(f'leakage chk : max(train time) {ttr.max():.4f} < min(test time) {tte.min():.4f} -> {ttr.max() < tte.min()}')
    from collections import Counter
    print('train subtypes:', dict(Counter(str_))); print('test  subtypes:', dict(Counter(ste)))
    print(f"unseen family 'botnet' in train: {int((str_=='botnet').sum())}, in test: {int((ste=='botnet').sum())}")
    t0 = time.time(); rf = RandomForestClassifier(n_estimators=300, max_depth=None, random_state=0, n_jobs=1).fit(Xtr, ytr); print(f'full model  : RandomForest(300 trees, unlimited depth) trained in {time.time()-t0:.1f}s')
    sc = rf.predict_proba(Xte)[:, 1]; pr = (sc >= 0.5).astype(int); m = metrics(yte, pr, sc)
    print(f"accuracy={m['acc']:.4f} precision={m['prec']:.4f} recall={m['rec']:.4f} F1={m['f1']:.4f} ROC-AUC={m['roc']:.4f} PR-AUC={m['pr']:.4f}")
    tn, fp, fn, tp = m['cm']; print('confusion matrix (rows=true, cols=pred):'); print(f'            pred_normal  pred_attack\n true_normal {tn:>11} {fp:>12}\n true_attack {fn:>11} {tp:>12}')
    imp = rf.feature_importances_; order = np.argsort(imp)[::-1]
    print('top-8 feature importances:', ', '.join(f'{FEATS[i]}={imp[i]:.3f}' for i in order[:8]))
    print('\nPer-subtype detection on the test set (rate = fraction predicted as attack):')
    print(f"{'subtype':<12}{'n':>6}{'true label':>11}{'pred attack':>12}{'rate':>8}")
    for k in ['normal', 'flash_crowd', 'dos', 'probe', 'slow_probe', 'r2l', 'u2r', 'botnet']:
        mk = ste == k
        if mk.sum(): print(f"{k:<12}{mk.sum():>6}{('attack' if yte[mk][0] else 'normal'):>11}{int(pr[mk].sum()):>12}{pr[mk].mean():>8.3f}")
    # ---- B3.2 counterexamples
    print('\n' + '=' * 100); print('TASK B3.2  mis-predictions, categorised'); print('=' * 100)
    wrong = np.where(pr != yte)[0]; print(f'{len(wrong)} errors of {len(yte)} test rows ({100*len(wrong)/len(yte):.2f}%)')
    cat = Counter((ste[i], 'FN' if yte[i] else 'FP') for i in wrong)
    for (k, e), c in sorted(cat.items(), key=lambda z: -z[1]): print(f'  {k:<12}{e}: {c}')
    print('\nSix example errors (one per category; standardised-free raw values for the 8 most important features):')
    shown = set(); hdr = ['row', 'subtype', 'truth', 'score'] + [FEATS[i] for i in order[:6]]
    print('  ' + ' '.join(f'{h:>13}' for h in hdr))
    for i in wrong:
        key = (ste[i], yte[i])
        if key in shown: continue
        shown.add(key)
        print('  ' + ' '.join(f'{v:>13}' for v in [str(i), ste[i], 'attack' if yte[i] else 'normal', f'{sc[i]:.2f}'] + [f'{Xte[i, j]:.2f}' for j in order[:6]]))
        if len(shown) >= 6: break
    # unseen-family demonstration + noise robustness
    bm = ste == 'botnet'; print(f"\nCOUNTEREXAMPLE CLASS 1 - unseen attack family: botnet recall = {pr[bm].mean():.3f} ({int(pr[bm].sum())}/{int(bm.sum())}); recall on seen attack families = {pr[(yte==1)&~bm].mean():.3f}")
    print('COUNTEREXAMPLE CLASS 2 - sensor noise: multiplicative log-normal noise on all byte/rate/count features at test time (seeded)')
    print(f"  {'noise sigma':>11}{'accuracy':>10}{'recall':>8}{'precision':>10}{'F1':>7}")
    rg = np.random.default_rng(3)
    for sg in (0.0, 0.1, 0.3, 0.6, 1.0):
        Xn = Xte.copy(); Xn[:, [1, 2, 3, 4, 9, 10]] *= rg.lognormal(0, sg, (len(Xte), 6)); Xn[:, [5, 6, 7, 8, 11, 12]] = np.clip(Xn[:, [5, 6, 7, 8, 11, 12]] + rg.normal(0, sg * .15, (len(Xte), 6)), 0, 1)
        pn = rf.predict(Xn); print(f"  {sg:>11.1f}{accuracy_score(yte,pn):>10.4f}{recall_score(yte,pn):>8.3f}{precision_score(yte,pn):>10.3f}{f1_score(yte,pn):>7.3f}")
    # ---- B3.4 full vs edge
    print('\n' + '=' * 100); print('TASK B3.4  compressed edge model (int8 LR early exit + 12-tree depth-8 forest) vs full model'); print('=' * 100)
    nodes = sum(e.tree_.node_count for e in rf.estimators_); depth_avg = np.mean([e.get_depth() for e in rf.estimators_])
    full_mem = sum(e.tree_.node_count * 64 + e.tree_.value.nbytes for e in rf.estimators_)
    buf = io.BytesIO(); pickle.dump(rf, buf); full_pickle = buf.tell()
    casc = EdgeCascade(Xtr, ytr, imp); cs, stg = casc.predict_batch(Xte); cp = (cs >= 0.5).astype(int); cm_ = metrics(yte, cp, cs)
    print(f'full model  : trees=300  total nodes={nodes:,}  mean depth={depth_avg:.1f}  node memory={full_mem/2**20:.1f} MiB  pickle={full_pickle/2**20:.1f} MiB')
    print(f'edge model  : stage-1 params={len(casc.wq)}+1 (int8)  stage-2 nodes={sum(len(tr[0]) for tr in casc.trees)}  size={casc.size_bytes()/1024:.1f} KiB  early-exit rate={np.mean(stg==1):.3f}')
    rng = np.random.default_rng(5); sel = rng.choice(len(Xte), 400, replace=False); samp = Xte[sel]
    f_mean, f_p95, f_thr = lat_stats(lambda x: rf.predict_proba(x.reshape(1, -1)), samp[:150], warm=5)
    e_mean, e_p95, e_thr = lat_stats(lambda x: casc.predict_one(x), samp)
    Xb = Xte[:5000]; t0 = time.perf_counter(); rf.predict_proba(Xb); fb = 5000 / (time.perf_counter() - t0)
    print(f"\n{'model':<26}{'acc':>7}{'prec':>7}{'recall':>8}{'F1':>7}{'ROC-AUC':>9}{'PR-AUC':>8}{'size':>12}{'mean ms':>9}{'p95 ms':>8}{'samples/s':>11}")
    print(f"{'FULL RF (300 trees)':<26}{m['acc']:>7.4f}{m['prec']:>7.4f}{m['rec']:>8.4f}{m['f1']:>7.4f}{m['roc']:>9.4f}{m['pr']:>8.4f}{full_pickle/2**20:>9.1f} MiB{f_mean:>9.3f}{f_p95:>8.3f}{f_thr:>11.0f}")
    print(f"{'EDGE cascade':<26}{cm_['acc']:>7.4f}{cm_['prec']:>7.4f}{cm_['rec']:>8.4f}{cm_['f1']:>7.4f}{cm_['roc']:>9.4f}{cm_['pr']:>8.4f}{casc.size_bytes()/1024:>9.1f} KiB{e_mean:>9.4f}{e_p95:>8.4f}{e_thr:>11.0f}")
    print(f'(full RF, 5000-sample batch call: {fb:,.0f} samples/s)')
    SLOW = 10
    print(f'\nbudget 50 ms/sample.  Sandbox x86 CPU measurement + projection to an edge CPU assumed {SLOW}x slower (ASSUMPTION, not measured):')
    print(f'  full RF  : sandbox p95 {f_p95:.2f} ms -> projected {f_p95*SLOW:.1f} ms  -> {"MEETS" if f_p95*SLOW <= 50 else "VIOLATES"} budget')
    print(f'  edge cascade: sandbox p95 {e_p95:.4f} ms -> projected {e_p95*SLOW:.3f} ms -> {"MEETS" if e_p95*SLOW <= 50 else "VIOLATES"} budget')
    print(f"\nAccuracy change edge vs full: accuracy {100*(cm_['acc']-m['acc']):+.2f} pts, recall {100*(cm_['rec']-m['rec']):+.2f} pts, precision {100*(cm_['prec']-m['prec']):+.2f} pts, F1 {100*(cm_['f1']-m['f1']):+.2f} pts, ROC-AUC {cm_['roc']-m['roc']:+.4f}")
    print('\nWhat was sacrificed - detection rate per subtype (test):')
    print(f"{'subtype':<12}{'full':>8}{'edge':>8}{'delta':>8}")
    for k in ['normal', 'flash_crowd', 'dos', 'probe', 'slow_probe', 'r2l', 'u2r', 'botnet']:
        mk = ste == k
        if mk.sum(): print(f'{k:<12}{pr[mk].mean():>8.3f}{cp[mk].mean():>8.3f}{cp[mk].mean()-pr[mk].mean():>+8.3f}')
    pickle.dump(dict(t=t, X=X, y=y, sub=sub, imp=imp, order=order, full=m, edge=cm_, f_lat=(f_mean, f_p95, f_thr), e_lat=(e_mean, e_p95, e_thr),
                     full_pickle=full_pickle, edge_size=casc.size_bytes(), nodes=nodes, sc=sc, cs=cs, pr=pr, cp=cp, ste=ste, yte=yte, stg=stg, full_mem=full_mem, fb=fb, depth=depth_avg), open('out/b3_state.pkl', 'wb'))
    pickle.dump(dict(top=casc.top, wq=casc.wq, wscale=casc.wscale, b=casc.b, mu=casc.mu, sd=casc.sd), open('out/edge_lr.pkl', 'wb'))
