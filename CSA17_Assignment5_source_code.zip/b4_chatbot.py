"""b4_chatbot.py - Task B4: retrieval-based operator assistant for the intrusion-detection system (10 intents + out-of-scope fallback)."""
import numpy as np, random, time, pickle
from sklearn.feature_extraction.text import TfidfVectorizer
from scipy.sparse import hstack
TRAIN = {
 'open_alerts': ["which alerts are open", "show me the open alerts", "list all active alerts", "what alerts are still unresolved", "any open incidents right now", "give me the current alert queue", "how many alerts are pending", "display unresolved security alerts", "what is in the alert list", "show active alarms"],
 'why_flagged': ["why was this flagged", "why did the model flag this flow", "explain this alert", "what made this connection suspicious", "which features triggered the detection", "give me the reason for this alert", "why is this traffic marked as an attack", "explain the detection decision", "what caused this alarm", "justify the flag on this record"],
 'severity': ["how severe is this alert", "what is the severity of the alarm", "is this alert critical", "rate the risk of this incident", "how dangerous is this flow", "what priority does this alert have", "tell me the threat level", "is this a high priority alert", "how serious is the detection", "severity level of the last alert"],
 'model_accuracy': ["how accurate is the detector", "what is the model accuracy", "what are the precision and recall", "how good is the detection model", "tell me the f1 score", "what is the false alarm rate", "how reliable are the alerts", "show model performance metrics", "how often is the model wrong", "what is the detection rate"],
 'latency': ["how fast is the detection", "what is the inference latency", "how long does scoring take", "is the model meeting the time budget", "what is the response time of the detector", "how many milliseconds per flow", "tell me the processing delay", "is the detector real time", "how quickly are flows scored", "what is the throughput"],
 'attack_types': ["what attacks can you detect", "which attack types are covered", "do you detect port scans", "can the system find denial of service", "list the supported threat categories", "does it catch password guessing", "what kinds of intrusions are recognised", "are botnets detected", "which threats does the model know", "what intrusion families are supported"],
 'block_host': ["block this ip address", "please block the attacker", "quarantine this host", "isolate the suspicious machine", "ban the source address", "cut off this host from the network", "add this ip to the blocklist", "stop traffic from this source", "deny the offending host", "blacklist this address"],
 'deployment': ["where does the model run", "is the detector on the edge or in the cloud", "which device runs the model", "is data sent to the cloud", "where is the assistant deployed", "does inference happen locally", "what hardware is the detector running on", "do you run on the edge device", "is my traffic leaving the site", "where is scoring performed"],
 'traffic_summary': ["summarise the recent traffic", "how many flows were processed today", "give me a traffic overview", "what is the current flow rate", "show traffic statistics", "how much traffic is normal", "what share of flows were attacks", "report network activity for the last hour", "how many connections per second", "traffic report please"],
 'greeting_help': ["hello", "hi there", "what can you do", "help", "good morning assistant", "how can you help me", "what questions can i ask", "hey", "show me the available commands", "who are you"],
}
TEST = {
 'open_alerts': ["are there any alerts open at the moment", "tell me which incidents are unresolved", "what's in the queue of active alerts", "show open alarms please", "number of alerts still pending", "can you list the unresolved alerts"],
 'why_flagged': ["why did you mark this record as malicious", "reason for the flag please", "what triggered this alarm", "can you explain why it was detected", "which signals made the model suspicious", "explain the alert on this flow"],
 'severity': ["how critical is the last incident", "what is the risk level of this alert", "is this one high severity", "give the threat priority of the alarm", "how bad is this detection", "rate the danger of this connection"],
 'model_accuracy': ["what accuracy does the detector have", "tell me precision and recall of the model", "how often does it raise false alarms", "show me the performance numbers", "is the model reliable", "what f1 does it achieve"],
 'latency': ["what is the delay for scoring a flow", "is detection fast enough for real time", "how many ms does inference take", "tell me the speed of the detector", "does it meet the latency budget", "what throughput can it sustain"],
 'attack_types': ["which kinds of attacks are supported", "can it detect scanning activity", "does the system recognise dos floods", "what threat types does it cover", "is brute force login detection included", "do you catch botnet beacons"],
 'block_host': ["please blacklist this source", "block the offending address", "isolate this machine from the network", "can you quarantine the attacker", "add the host to the deny list", "cut this ip off"],
 'deployment': ["does the model run locally or in the cloud", "where is inference executed", "is the detector deployed on the edge", "does my data leave the premises", "on what device is the assistant running", "is scoring done on site"],
 'traffic_summary': ["give me an overview of network activity", "how many flows did we handle", "show me the traffic numbers", "what percent of traffic was malicious", "flow rate right now please", "produce a traffic summary for the last hour"],
 'greeting_help': ["hello assistant", "hi", "what are the things you can do", "i need help", "good evening", "which commands are available"],
}
OOS_TEST = ["what is the weather today", "tell me a joke", "who won the football match", "how do i bake bread", "book me a flight to paris", "what is the capital of japan",
 "play some music", "translate this sentence to french", "what is the price of bitcoin", "recommend a good movie", "how tall is mount everest", "set an alarm for seven",
 "order a pizza", "what is the meaning of life", "write me a poem", "how do i fix my bicycle", "what time is it in tokyo", "tell me about the roman empire",
 "who is the president", "calculate fifteen percent of two hundred", "what should i cook tonight", "how many calories in an apple", "sing a song", "when is the next holiday",
 "how do i learn guitar", "give me a workout plan", "what is quantum physics", "find a nearby restaurant", "reset my email password", "is it going to rain tomorrow"]
from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS
from sklearn.preprocessing import normalize
STOP = list(ENGLISH_STOP_WORDS - {'not', 'no'}) + ['please', 'tell', 'give', 'show', 'can', 'you', 'what', 'is', 'the', 'me', 'this', 'it', 'how', 'are']
class Bot:
    """mode 'v1' = word 1-2gram + char 3-4gram TF-IDF (first design); 'v2' = word 1-2gram TF-IDF with question/stop words removed (improved)."""
    def __init__(s, train=TRAIN, mode='v2'):
        s.mode = mode; s.utts, s.lab = [], []
        for k, v in train.items():
            for u in v: s.utts.append(u); s.lab.append(k)
        s.w = TfidfVectorizer(ngram_range=(1, 2), sublinear_tf=True, stop_words=STOP if mode == 'v2' else None)
        s.c = TfidfVectorizer(analyzer='char_wb', ngram_range=(3, 4), sublinear_tf=True)
        s.M = s._vec(s.utts, fit=True); s.lab = np.array(s.lab)
    def _vec(s, u, fit=False):
        a = s.w.fit_transform(u) if fit else s.w.transform(u)
        if s.mode == 'v2': return normalize(a.tocsr())
        b = s.c.fit_transform(u) if fit else s.c.transform(u)
        return normalize(hstack([a, b]).tocsr())
    def scores(s, utts):
        S = (s._vec(utts) @ s.M.T).toarray(); j = S.argmax(1); return s.lab[j], S.max(1)
    def predict(s, utts, tau):
        lab, sc = s.scores(utts); return np.where(sc >= tau, lab, 'out_of_scope'), sc
VOCAB = sorted({w for v in TRAIN.values() for u in v for w in u.split()} | {w for u in OOS_TEST for w in u.split()})
def corrupt(u, wer, rng):
    out = []
    for w in u.split():
        if rng.random() < wer:
            r = rng.random()
            if r < .5: out.append(rng.choice(VOCAB))
            elif r < .75: pass
            else: out += [w, rng.choice(VOCAB)]
        else: out.append(w)
    return ' '.join(out) if out else rng.choice(VOCAB)
def evaluate(bot, tau, wer=0.0, reps=20, seed=0):
    rng = random.Random(seed); X, Y = [], []
    for k, v in TEST.items(): X += v; Y += [k] * len(v)
    X += OOS_TEST; Y += ['out_of_scope'] * len(OOS_TEST); Y = np.array(Y); preds = []
    for _ in range(reps if wer > 0 else 1):
        Xc = [corrupt(u, wer, rng) if wer > 0 else u for u in X]; p, sc = bot.predict(Xc, tau); preds.append(p)
    P = np.concatenate(preds); YY = np.tile(Y, len(preds)); ins = YY != 'out_of_scope'
    acc_in = np.mean(P[ins] == YY[ins]); oos_det = np.mean(P[~ins] == 'out_of_scope'); far = np.mean(P[~ins] != 'out_of_scope')
    return acc_in, oos_det, far, P, YY
if __name__ == '__main__':
    labels = list(TRAIN) + ['out_of_scope']
    v1 = Bot(mode='v1'); taus1 = np.round(np.arange(0.0, 0.91, 0.05), 2); t1 = float(max(taus1, key=lambda t: sum(evaluate(v1, t)[:2]))); r1 = evaluate(v1, t1)
    print('FIRST DESIGN (v1: word+char TF-IDF): best tau=%.2f -> in-scope acc %.3f, OOS detect %.3f, false-accept %.3f  (weak: shared question words such as "what is the" match OOS queries)' % (t1, r1[0], r1[1], r1[2]))
    print('   v1 under WER 30%%: in-scope acc %.3f, OOS detect %.3f\n' % evaluate(v1, t1, 0.3)[:2])
    bot = Bot(mode='v2')
    print('=' * 100); print(f'TASK B4.1  retrieval chatbot: {len(TRAIN)} intents, {sum(len(v) for v in TRAIN.values())} training utterances, {sum(len(v) for v in TEST.values())} in-scope + {len(OOS_TEST)} out-of-scope TEST utterances'); print('=' * 100)
    print('model (v2): TF-IDF word 1-2gram with question/stop words removed, cosine similarity to nearest training utterance, reject if max cosine < tau')
    # choose tau on WER=0 sweep: maximise (in-scope acc + OOS detection)/2  - NOTE: chosen on the same data used for reporting -> optimistic, stated in report
    taus = np.round(np.arange(0.0, 0.91, 0.05), 2); best = max(taus, key=lambda t: sum(evaluate(bot, t)[:2]))
    TAU = float(best); print(f'tau selected at WER=0: {TAU}')
    a, o, f, P, Y = evaluate(bot, TAU)
    print(f'in-scope intent accuracy = {a:.3f} | OOS detection = {o:.3f} | false-accept rate = {f:.3f}')
    from sklearn.metrics import precision_recall_fscore_support, confusion_matrix
    p, r, f1, sup = precision_recall_fscore_support(Y, P, labels=labels, zero_division=0)
    print(f"\n{'intent':<18}{'precision':>10}{'recall':>8}{'F1':>7}{'support':>8}")
    for l, pp, rr, ff, ss in zip(labels, p, r, f1, sup): print(f'{l:<18}{pp:>10.2f}{rr:>8.2f}{ff:>7.2f}{ss:>8}')
    print(f"{'macro avg':<18}{p.mean():>10.2f}{r.mean():>8.2f}{f1.mean():>7.2f}")
    cm = confusion_matrix(Y, P, labels=labels); ab = ['open', 'why', 'sev', 'acc', 'lat', 'atk', 'blk', 'dep', 'trf', 'hlp', 'oos']
    print('\nconfusion matrix (rows = true, cols = predicted):'); print(' ' * 6 + ''.join(f'{x:>5}' for x in ab))
    for x, row in zip(ab, cm): print(f'{x:>6}' + ''.join(f'{v:>5}' for v in row))
    allq = [u for v in TEST.values() for u in v] + OOS_TEST; ts = []
    for u in allq * 3:
        t0 = time.perf_counter(); bot.predict([u], TAU); ts.append((time.perf_counter() - t0) * 1e3)
    print(f'\nresponse latency per query: mean {np.mean(ts):.2f} ms, p95 {np.percentile(ts, 95):.2f} ms (classification only)  | model size: {bot.M.data.nbytes/1024 + bot.M.indices.nbytes/1024:.0f} KiB matrix')
    print('\n' + '=' * 100); print('TASK B4.2  speech-recognition errors simulated by word corruption (substitute 50% / delete 25% / insert 25%), 20 random corruptions per WER'); print('=' * 100)
    print(f"{'WER':>5}{'intent acc':>12}{'OOS detect':>12}{'false-accept':>14}")
    sweep = {}
    for w in (0.0, 0.1, 0.2, 0.3):
        a, o, f, _, _ = evaluate(bot, TAU, w); print(f'{w:>5.0%}{a:>12.3f}{o:>12.3f}{f:>14.3f}')
    print('\nthreshold sweep (columns: in-scope acc / false-accept rate):'); print(f"{'tau':>5}" + ''.join(f'   WER {w:.0%} acc/FAR' for w in (0, .1, .2, .3)))
    for t in taus:
        row = f'{t:>5.2f}'
        for w in (0.0, 0.1, 0.2, 0.3):
            a, o, f, _, _ = evaluate(bot, t, w); sweep[(w, float(t))] = (a, o, f); row += f'   {a:>6.3f}/{f:<6.3f}'
        print(row)
    pickle.dump(dict(sweep=sweep, taus=taus, TAU=TAU), open('out/b4_sweep.pkl', 'wb'))
    # ---------------- demo transcript wired to the B3 detector state
    st = pickle.load(open('out/b3_state.pkl', 'rb')); lr = pickle.load(open('out/edge_lr.pkl', 'rb'))
    from b3_ids import FEATS, split
    (Xtr, *_), (Xte, yte, ste, tte) = split(st['t'], st['X'], st['y'], st['sub'])
    cs = st['cs']; opened = np.argsort(-cs)[:3]
    def answer(intent, aid):
        if intent == 'open_alerts': return f"{int((cs >= 0.5).sum())} flows flagged in the last window; top open alerts: " + ', '.join(f'#{i} (score {cs[i]:.2f})' for i in opened)
        if intent == 'why_flagged':
            z = (Xte[aid, lr['top']] - lr['mu']) / lr['sd'] * lr['wq'] / lr['wscale']; o = np.argsort(-z)[:3]
            return f'Alert #{aid} (score {cs[aid]:.2f}): strongest contributors = ' + ', '.join(f"{FEATS[lr['top'][j]]} ({z[j]:+.2f})" for j in o)
        if intent == 'severity': return f'Alert #{aid}: score {cs[aid]:.2f} -> ' + ('HIGH' if cs[aid] > .9 else 'MEDIUM' if cs[aid] > .7 else 'LOW')
        if intent == 'model_accuracy': return f"Edge model on held-out future data: precision {st['edge']['prec']:.3f}, recall {st['edge']['rec']:.3f}, F1 {st['edge']['f1']:.3f}"
        if intent == 'latency': return f"Edge cascade p95 latency {st['e_lat'][1]:.3f} ms on this host (budget 50 ms)"
        if intent == 'deployment': return 'Detector and assistant both run on the edge device; only alert summaries go to the cloud.'
        if intent == 'attack_types': return 'Trained on DoS, probe, R2L, U2R. Not reliable for unseen families such as botnet beaconing.'
        if intent == 'traffic_summary': return f"{len(cs)} flows scored; {100*np.mean(cs>=0.5):.1f}% flagged."
        if intent == 'block_host': return 'Blocking is an action; it needs operator confirmation and is not performed automatically.'
        return 'I can answer questions about alerts, severity, accuracy, latency, attack coverage, deployment and traffic.'
    print('\n' + '=' * 100); print('Demo transcript (assistant wired to the B3 edge detector state)'); print('=' * 100)
    for u in ["which alerts are open right now", f"why was alert {opened[0]} flagged", "how severe is it", "how fast is the detector", "what is the weather in delhi", "block it", "hmm what can you do"]:
        p, sc = bot.predict([u], TAU); it = p[0]
        print(f'USER : {u}\nBOT  : [{it}, cos={sc[0]:.2f}] ' + ("Sorry, I can only help with the intrusion-detection system." if it == 'out_of_scope' else answer(it, int(opened[0]))))
