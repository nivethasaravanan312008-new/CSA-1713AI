import numpy as np, pickle, re, textwrap, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from PIL import Image, ImageDraw, ImageFont
plt.rcParams.update({'font.size': 9, 'axes.spines.top': False, 'axes.spines.right': False, 'figure.dpi': 150})
FONT = '/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf'; FB = '/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf'
def term(lines, title, path, fs=14):
    f = ImageFont.truetype(FONT, fs); cw = f.getlength('M'); lh = int(fs * 1.38)
    w = int(max(len(l) for l in lines) * cw + 50); w = max(w, 640); h = 40 + lh * len(lines) + 24
    im = Image.new('RGB', (w, h), '#1e1e1e'); d = ImageDraw.Draw(im); d.rectangle([0, 0, w, 32], fill='#3a3a3a')
    for k, c in enumerate(('#ff5f56', '#ffbd2e', '#27c93f')): d.ellipse([14 + 22 * k, 10, 26 + 22 * k, 22], fill=c)
    tf = ImageFont.truetype(FONT, 12); d.text((w / 2 - tf.getlength(title) / 2, 9), title, font=tf, fill='#cfcfcf')
    y = 44
    for l in lines:
        col = '#e0e0e0'
        if l.startswith('===') or l.startswith('TASK') or l.startswith('---'): col = '#4ec9b0'
        elif re.match(r'^\[S\d\]|^A2\.\d|^EDIT|^AC\d|^COUNTEREX|^LINEAGE|^USER', l): col = '#dcdcaa'
        elif 'RESULT' in l or '-> outcome' in l or 'MEETS' in l or 'VIOLATES' in l or 'REGRESSION' in l or 'FIXED' in l: col = '#ce9178'
        d.text((22, y), l, font=f, fill=col); y += lh
    im.save(path); return path
def shots(src, start, end, title, tag, per=44, cap=150, fs=14):
    L = open(src).read().split('\n'); a = next(i for i, l in enumerate(L) if start in l) if start else 0
    b = next((i for i, l in enumerate(L) if i > a and end in l), len(L)) if end else len(L)
    seg = [l[:cap] for l in L[a:b]]
    while seg and not seg[-1].strip(): seg.pop()
    parts = [seg[i:i + per] for i in range(0, len(seg), per)]; out = []
    for k, p in enumerate(parts): out.append(term(p, f'{title}' + (f'  ({k+1}/{len(parts)})' if len(parts) > 1 else ''), f'img/{tag}_{k}.png', fs))
    return out
def build():
    manifest = {}
    O = 'out/'
    manifest['drone_main'] = shots(O + 'b1_drone.txt', '[S1]', '[S3]', 'python3 b1_drone_agent.py  -  terminal', 'drone_a')
    manifest['drone_s3'] = shots(O + 'b1_drone.txt', '[S3]', '[S5]', 'python3 b1_drone_agent.py  -  terminal', 'drone_b')
    manifest['drone_s5'] = shots(O + 'b1_drone.txt', '[S5]', None, 'python3 b1_drone_agent.py  -  terminal', 'drone_c')
    manifest['trace_a23'] = shots(O + 'b1_swarm_extra.txt', 'A2.3  spread', 'A2.4  failure', 'python3 b1_swarm_extra.py  -  terminal', 'tr23', per=60)
    manifest['trace_a24'] = shots(O + 'b1_swarm_wall.txt', None, 'Same configuration', 'python3 b1_swarm_wall.py  -  terminal', 'tr24', per=60)
    manifest['wall_tail'] = shots(O + 'b1_swarm_wall.txt', 'RESULT', None, 'python3 b1_swarm_wall.py  -  terminal', 'tr24t')
    manifest['swarm_table'] = shots(O + 'b1_swarm_table.txt', '====', None, 'python3 b1_swarm.py  -  terminal', 'swt', per=40, cap=130)
    manifest['central'] = shots(O + 'b1_swarm_extra.txt', 'A2.1 diagnosis', None, 'python3 b1_swarm_extra.py  -  terminal', 'cen', per=40, cap=130)
    manifest['b2_rules'] = shots(O + 'b2_main.txt', 'TASK B2.1', '--- DEVELOPMENT', 'python3 b2_expert_shell.py  -  terminal', 'b2r', per=40, cap=150)
    manifest['b2_dev'] = shots(O + 'b2_main.txt', '--- DEVELOPMENT', '--- HOLD-OUT', 'python3 b2_expert_shell.py  -  terminal', 'b2d', per=40)
    manifest['b2_hold'] = shots(O + 'b2_main.txt', '--- HOLD-OUT', '--- sample', 'python3 b2_expert_shell.py  -  terminal', 'b2h', per=40)
    manifest['b2_expl'] = shots(O + 'b2_main.txt', '--- sample', None, 'python3 b2_expert_shell.py  -  terminal', 'b2e', per=40)
    manifest['b2_adv'] = shots(O + 'b2_adv.txt', 'TASK B2.2', '--- rule-order', 'python3 b2_adversarial.py  -  terminal', 'b2a', per=42, cap=140)
    manifest['b2_order'] = shots(O + 'b2_adv.txt', '--- rule-order', 'TASK B2.3', 'python3 b2_adversarial.py  -  terminal', 'b2o', per=42, cap=140)
    manifest['b2_ka'] = shots(O + 'b2_adv.txt', 'TASK B2.3', None, 'python3 b2_adversarial.py  -  terminal', 'b2k', per=42, cap=140)
    manifest['b3_a'] = shots(O + 'b3_main.txt', 'TASK B3.1', 'TASK B3.2', 'python3 b3_ids.py  -  terminal', 'b3a', per=42, cap=140)
    manifest['b3_b'] = shots(O + 'b3_main.txt', 'TASK B3.2', 'TASK B3.4', 'python3 b3_ids.py  -  terminal', 'b3b', per=42, cap=150)
    manifest['b3_c'] = shots(O + 'b3_main.txt', 'TASK B3.4', None, 'python3 b3_ids.py  -  terminal', 'b3c', per=42, cap=170, fs=13)
    manifest['rdd'] = shots(O + 'b3_rdd.txt', 'TASK A4/B3.3', 'LINEAGE RECOVERY', 'python3 b3_rdd.py  -  terminal', 'rdd', per=44, cap=140)
    manifest['rdd_lin'] = shots(O + 'b3_rdd.txt', 'LINEAGE RECOVERY', None, 'python3 b3_rdd.py  -  terminal', 'rddl', per=44)
    manifest['b4_a'] = shots(O + 'b4_main.txt', 'FIRST DESIGN', 'TASK B4.2', 'python3 b4_chatbot.py  -  terminal', 'b4a', per=44, cap=165)
    manifest['b4_b'] = shots(O + 'b4_main.txt', 'TASK B4.2', 'Demo transcript', 'python3 b4_chatbot.py  -  terminal', 'b4b', per=44, cap=140)
    manifest['b4_c'] = shots(O + 'b4_main.txt', 'Demo transcript', None, 'python3 b4_chatbot.py  -  terminal', 'b4c', per=44, cap=180, fs=13)
    # ------------------------------------------------ figures
    curves, summ = pickle.load(open(O + 'swarm_curves.pkl', 'rb')); Ns = (1, 5, 10, 25, 50); col = dict(zip(Ns, ['#444', '#1f77b4', '#2ca02c', '#ff7f0e', '#d62728']))
    fig, ax = plt.subplots(1, 3, figsize=(10, 3.2), sharey=True)
    for a, f in zip(ax, (0.0, 0.1, 0.3)):
        for n in Ns: a.plot(curves[(n, f)] * 100, label=f'N={n}', color=col[n], lw=1.6)
        a.axhline(90, ls='--', c='grey', lw=.8); a.set_title(f'{int(f*100)}% drones fail'); a.set_xlabel('time step'); a.set_xlim(0, 150)
    ax[0].set_ylabel('mean coverage (%)'); ax[0].legend(frameon=False, fontsize=8); fig.tight_layout(); fig.savefig('img/f_cov.png'); plt.close()
    fig, ax = plt.subplots(1, 3, figsize=(10, 3.0)); w = .26
    for k, f in enumerate((0.0, .1, .3)): ax[0].bar(np.arange(5) + (k - 1) * w, [summ[(n, f)]['success'] * 100 for n in Ns], w, label=f'{int(f*100)}% fail')
    ax[0].set_xticks(range(5)); ax[0].set_xticklabels(Ns); ax[0].set_xlabel('N drones'); ax[0].set_ylabel('mission success (%)'); ax[0].legend(frameon=False, fontsize=8)
    ax[1].plot(Ns, [summ[(n, 0.0)]['red'] for n in Ns], 'o-', label='redundancy ratio'); ax[1].plot(Ns, [summ[(n, 0.0)]['pb'] for n in Ns], 's-', label='battery used / drone')
    ax[1].set_xscale('log'); ax[1].set_xlabel('N drones'); ax[1].legend(frameon=False, fontsize=8); ax[1].set_ylim(0, 1.05)
    ax[2].plot(Ns, [summ[(n, 0.0)]['lat'] for n in Ns], 'o-', c='#9467bd'); ax[2].set_xscale('log'); ax[2].set_xlabel('N drones'); ax[2].set_ylabel('decision latency (us)')
    fig.tight_layout(); fig.savefig('img/f_scale.png'); plt.close()
    cv = pickle.load(open(O + 'central_vs_swarm.pkl', 'rb')); fig, ax = plt.subplots(1, 2, figsize=(9, 3))
    sc = ['no failure', 'controller/link down at t=30', '30% drones fail', '30% drones + controller down t=30']
    for a, n in zip(ax, (10, 25)):
        for k, mode in enumerate(('central', 'swarm')): a.bar(np.arange(4) + (k - .5) * .38, [cv[(n, mode, s)][1] for s in sc], .38, label=mode)
        a.set_xticks(range(4)); a.set_xticklabels(['none', 'ctrl down', '30% drones', 'both'], fontsize=8); a.set_title(f'N={n}'); a.set_ylabel('final coverage (%)')
    ax[0].legend(frameon=False); fig.tight_layout(); fig.savefig('img/f_central.png'); plt.close()
    st = pickle.load(open(O + 'b3_state.pkl', 'rb')); from sklearn.metrics import roc_curve, precision_recall_curve
    fig, ax = plt.subplots(1, 3, figsize=(10, 3.1))
    for nm, s_, c in (('full RF', st['sc'], '#1f77b4'), ('edge cascade', st['cs'], '#d62728')):
        fp, tp, _ = roc_curve(st['yte'], s_); ax[0].plot(fp, tp, label=nm, c=c); p, r, _ = precision_recall_curve(st['yte'], s_); ax[1].plot(r, p, label=nm, c=c)
    ax[0].set_xlabel('false-positive rate'); ax[0].set_ylabel('true-positive rate'); ax[0].legend(frameon=False); ax[1].set_xlabel('recall'); ax[1].set_ylabel('precision')
    sub = st['ste']; ks = ['normal', 'flash_crowd', 'dos', 'probe', 'slow_probe', 'r2l', 'u2r', 'botnet']
    x = np.arange(len(ks)); ax[2].bar(x - .2, [st['pr'][sub == k].mean() for k in ks], .4, label='full'); ax[2].bar(x + .2, [st['cp'][sub == k].mean() for k in ks], .4, label='edge')
    ax[2].set_xticks(x); ax[2].set_xticklabels(ks, rotation=60, ha='right', fontsize=7); ax[2].set_ylabel('fraction flagged'); ax[2].legend(frameon=False, fontsize=8)
    fig.tight_layout(); fig.savefig('img/f_ids.png'); plt.close()
    rows = pickle.load(open(O + 'rdd_rows.pkl', 'rb')); fig, ax = plt.subplots(1, 2, figsize=(9, 3))
    for total, c in ((10**5, '#1f77b4'), (10**6, '#2ca02c'), (10**7, '#d62728')):
        for cache, ls in ((False, '-'), (True, '--')):
            r = [(x[1], x[3] + x[4]) for x in rows if x[0] == total and x[2] == cache]
            if r: ax[0].plot(*zip(*r), ls, marker='o', c=c, label=f'{total:.0e} {"cached" if cache else "no cache"}')
    ax[0].set_yscale('log'); ax[0].set_xscale('log', base=2); ax[0].set_xticks([1, 2, 4, 8]); ax[0].set_xticklabels([1, 2, 4, 8]); ax[0].set_xlabel('partitions'); ax[0].set_ylabel('two actions, total s'); ax[0].legend(frameon=False, fontsize=7)
    tot = 10**6; v = {P: [x for x in rows if x[0] == tot and x[1] == P and not x[2]][0] for P in (1, 2, 4, 8)}
    ax[1].bar(range(4), [v[P][3] for P in v], label='action 1'); ax[1].bar(range(4), [v[P][4] for P in v], bottom=[v[P][3] for P in v], label='action 2 (recompute)')
    ax[1].set_xticks(range(4)); ax[1].set_xticklabels([1, 2, 4, 8]); ax[1].set_xlabel('partitions (10^6 records, no cache)'); ax[1].set_ylabel('seconds'); ax[1].legend(frameon=False, fontsize=8)
    fig.tight_layout(); fig.savefig('img/f_rdd.png'); plt.close()
    sw = pickle.load(open(O + 'b4_sweep.pkl', 'rb')); fig, ax = plt.subplots(1, 3, figsize=(10, 3.1)); taus = sw['taus']
    for w, c in zip((0, .1, .2, .3), ['#444', '#1f77b4', '#ff7f0e', '#d62728']):
        ax[0].plot(taus, [sw['sweep'][(w, float(t))][0] for t in taus], c=c, label=f'WER {int(w*100)}%'); ax[1].plot(taus, [sw['sweep'][(w, float(t))][2] for t in taus], c=c)
        ax[2].plot([sw['sweep'][(w, float(t))][2] for t in taus], [sw['sweep'][(w, float(t))][0] for t in taus], c=c)
    ax[0].set_xlabel('threshold tau'); ax[0].set_ylabel('in-scope intent accuracy'); ax[0].legend(frameon=False, fontsize=8); ax[1].set_xlabel('threshold tau'); ax[1].set_ylabel('false-accept rate (OOS)')
    ax[2].set_xlabel('false-accept rate'); ax[2].set_ylabel('in-scope accuracy'); fig.tight_layout(); fig.savefig('img/f_thr.png'); plt.close()
    pickle.dump(manifest, open('out/manifest.pkl', 'wb')); print({k: len(v) for k, v in manifest.items()})
build()
